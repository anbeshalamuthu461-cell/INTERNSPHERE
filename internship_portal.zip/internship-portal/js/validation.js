
/* =========================================
   InternSphere
   Student Internship and Recruitment Portal
   Form Validation JavaScript
========================================= */

/* =========================================
   1. REGISTRATION FORM VALIDATION
========================================= */

function validateRegister() {
    const firstName = document.getElementById('first_name');
    const lastName = document.getElementById('last_name');
    const age = document.getElementById('age');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const role = document.getElementById('role');

    // Check whether required fields exist
    if (!firstName || !lastName || !age ||
        !email || !password || !role) {
        alert('Registration form fields are missing.');
        return false;
    }

    // Check empty fields
    if (
        !firstName.value.trim() ||
        !lastName.value.trim() ||
        !age.value.trim() ||
        !email.value.trim() ||
        !password.value.trim() ||
        !role.value
    ) {
        alert('Please complete all fields.');

        if (!firstName.value.trim()) {
            firstName.focus();
        } else if (!lastName.value.trim()) {
            lastName.focus();
        } else if (!age.value.trim()) {
            age.focus();
        } else if (!email.value.trim()) {
            email.focus();
        } else if (!password.value.trim()) {
            password.focus();
        } else {
            role.focus();
        }

        return false;
    }

    // Validate first name
    const namePattern = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*$/u;

    if (!namePattern.test(firstName.value.trim())) {
        alert('Please enter a valid first name.');
        firstName.focus();
        return false;
    }

    // Validate last name
    if (!namePattern.test(lastName.value.trim())) {
        alert('Please enter a valid last name.');
        lastName.focus();
        return false;
    }

    // Validate age
    const ageValue = Number(age.value);

    if (
        !Number.isInteger(ageValue) ||
        ageValue < 16 ||
        ageValue > 100
    ) {
        alert('Age must be a whole number between 16 and 100.');
        age.focus();
        return false;
    }

    // Validate email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email.value.trim())) {
        alert('Please enter a valid email address.');
        email.focus();
        return false;
    }

    // Validate password length
    if (password.value.length < 6) {
        alert('Password must contain at least 6 characters.');
        password.focus();
        return false;
    }

    // Validate account role
    if (
        role.value !== 'student' &&
        role.value !== 'company'
    ) {
        alert('Please select a valid account type.');
        role.focus();
        return false;
    }

    // Registration validation successful
    return true;
}


/* =========================================
   2. LOGIN FORM VALIDATION
========================================= */

function validateLogin() {
    const email = document.getElementById('email');
    const password = document.getElementById('password');

    // Check whether login fields exist
    if (!email || !password) {
        alert('Login form fields are missing.');
        return false;
    }

    // Check empty email
    if (!email.value.trim()) {
        alert('Please enter your email address.');
        email.focus();
        return false;
    }

    // Check email format
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email.value.trim())) {
        alert('Please enter a valid email address.');
        email.focus();
        return false;
    }

    // Check empty password
    if (!password.value.trim()) {
        alert('Please enter your password.');
        password.focus();
        return false;
    }

    // Login form validation successful
    return true;
}


/* =========================================
   3. CONFIRM PASSWORD VALIDATION
   Optional: use only if your form has
   an input with id="confirm_password".
========================================= */

function validateConfirmPassword() {
    const password = document.getElementById('password');
    const confirmPassword =
        document.getElementById('confirm_password');

    if (!password || !confirmPassword) {
        return true;
    }

    if (password.value !== confirmPassword.value) {
        alert('Passwords do not match.');
        confirmPassword.focus();
        return false;
    }

    return true;
}


/* =========================================
   4. PREVENT MULTIPLE FORM SUBMISSIONS
   Optional helper for submit buttons.
========================================= */

function preventDuplicateSubmission(form) {
    if (!form) {
        return true;
    }

    if (form.dataset.submitted === 'true') {
        return false;
    }

    form.dataset.submitted = 'true';

    return true;
}


/* =========================================
   5. GENERAL INPUT CLEANUP
   Remove leading/trailing spaces when
   leaving name and email fields.
========================================= */

document.addEventListener('DOMContentLoaded', function () {
    const trimFields = [
        'first_name',
        'last_name',
        'email'
    ];

    trimFields.forEach(function (fieldId) {
        const field = document.getElementById(fieldId);

        if (field) {
            field.addEventListener('blur', function () {
                field.value = field.value.trim();
            });
        }
    });
});
