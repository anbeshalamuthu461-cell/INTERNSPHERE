
(function () {
    'use strict';

    const STORAGE_KEY = 'internsphere_language';
    const DEFAULT_LANGUAGE = 'en';

    const translations = {
        en: {
            home: 'Home',
            login: 'Login',
            register: 'Create Account',
            logout: 'Logout',
            dashboard: 'Dashboard',
            welcome: 'Welcome to InternSphere',
            tagline: 'Find your dream internship and start your career.',
            getStarted: 'Get Started',
            exploreInternships: 'Explore Internships',
            email: 'Email Address',
            password: 'Password',
            confirmPassword: 'Confirm Password',
            firstName: 'First Name',
            lastName: 'Last Name',
            fullName: 'Full Name',
            age: 'Age',
            role: 'Register As',
            student: 'Student',
            company: 'Company',
            submit: 'Submit',
            signIn: 'Sign In',
            signUp: 'Sign Up',
            createAccount: 'Create Account',
            alreadyAccount: 'Already have an account?',
            noAccount: "Don't have an account?",
            internships: 'Internships',
            profile: 'My Profile',
            applications: 'My Applications',
            companyName: 'Company Name',
            title: 'Title',
            description: 'Description',
            location: 'Location',
            apply: 'Apply Now',
            search: 'Search',
            save: 'Save Changes',
            cancel: 'Cancel',
            language: 'Language',
            required: 'This field is required.',
            footer: 'All rights reserved.',
            opportunities: 'Discover New Opportunities',
            learnGrow: 'Learn, Grow and Build Your Career',
            findInternship: 'Find Internships',
            viewDetails: 'View Details',
            noResults: 'No results found.',
            loading: 'Loading...',
            back: 'Back',
            next: 'Next',
            previous: 'Previous',
            status: 'Status',
            pending: 'Pending',
            approved: 'Approved',
            rejected: 'Rejected',
            open: 'Open',
            closed: 'Closed'
        },

        ta: {
            home: 'முகப்பு',
            login: 'உள்நுழை',
            register: 'கணக்கை உருவாக்கு',
            logout: 'வெளியேறு',
            dashboard: 'முகப்புப் பலகை',
            welcome: 'InternSphere-க்கு வரவேற்கிறோம்',
            tagline: 'உங்கள் கனவு இன்டர்ன்ஷிப்பைக் கண்டுபிடித்து தொழில் பயணத்தைத் தொடங்குங்கள்.',
            getStarted: 'தொடங்குங்கள்',
            exploreInternships: 'இன்டர்ன்ஷிப்புகளைப் பாருங்கள்',
            email: 'மின்னஞ்சல் முகவரி',
            password: 'கடவுச்சொல்',
            confirmPassword: 'கடவுச்சொல்லை உறுதிப்படுத்தவும்',
            firstName: 'முதல் பெயர்',
            lastName: 'கடைசி பெயர்',
            fullName: 'முழுப் பெயர்',
            age: 'வயது',
            role: 'பதிவு செய்யும் வகை',
            student: 'மாணவர்',
            company: 'நிறுவனம்',
            submit: 'சமர்ப்பிக்கவும்',
            signIn: 'உள்நுழைக',
            signUp: 'பதிவு செய்யவும்',
            createAccount: 'கணக்கை உருவாக்கு',
            alreadyAccount: 'ஏற்கனவே கணக்கு உள்ளதா?',
            noAccount: 'கணக்கு இல்லையா?',
            internships: 'இன்டர்ன்ஷிப்புகள்',
            profile: 'எனது சுயவிவரம்',
            applications: 'எனது விண்ணப்பங்கள்',
            companyName: 'நிறுவனத்தின் பெயர்',
            title: 'தலைப்பு',
            description: 'விளக்கம்',
            location: 'இடம்',
            apply: 'இப்போது விண்ணப்பிக்கவும்',
            search: 'தேடல்',
            save: 'மாற்றங்களைச் சேமி',
            cancel: 'ரத்து செய்',
            language: 'மொழி',
            required: 'இந்தப் புலத்தை நிரப்ப வேண்டும்.',
            footer: 'அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.',
            opportunities: 'புதிய வாய்ப்புகளைக் கண்டறியுங்கள்',
            learnGrow: 'கற்றுக்கொள்ளுங்கள், வளருங்கள், தொழிலை உருவாக்குங்கள்',
            findInternship: 'இன்டர்ன்ஷிப்பைக் கண்டறியுங்கள்',
            viewDetails: 'விவரங்களைப் பார்க்கவும்',
            noResults: 'முடிவுகள் எதுவும் இல்லை.',
            loading: 'ஏற்றப்படுகிறது...',
            back: 'பின்செல்',
            next: 'அடுத்து',
            previous: 'முந்தையது',
            status: 'நிலை',
            pending: 'நிலுவையில்',
            approved: 'அங்கீகரிக்கப்பட்டது',
            rejected: 'நிராகரிக்கப்பட்டது',
            open: 'திறந்துள்ளது',
            closed: 'மூடப்பட்டுள்ளது'
        },

        hi: {
            home: 'होम',
            login: 'लॉगिन',
            register: 'खाता बनाएँ',
            logout: 'लॉगआउट',
            dashboard: 'डैशबोर्ड',
            welcome: 'InternSphere में आपका स्वागत है',
            tagline: 'अपनी पसंद की इंटर्नशिप खोजें और करियर शुरू करें।',
            getStarted: 'शुरू करें',
            exploreInternships: 'इंटर्नशिप देखें',
            email: 'ईमेल पता',
            password: 'पासवर्ड',
            confirmPassword: 'पासवर्ड की पुष्टि करें',
            firstName: 'पहला नाम',
            lastName: 'उपनाम',
            fullName: 'पूरा नाम',
            age: 'आयु',
            role: 'पंजीकरण का प्रकार',
            student: 'विद्यार्थी',
            company: 'कंपनी',
            submit: 'जमा करें',
            signIn: 'साइन इन',
            signUp: 'साइन अप',
            createAccount: 'खाता बनाएँ',
            alreadyAccount: 'क्या आपके पास पहले से खाता है?',
            noAccount: 'क्या आपके पास खाता नहीं है?',
            internships: 'इंटर्नशिप',
            profile: 'मेरी प्रोफ़ाइल',
            applications: 'मेरे आवेदन',
            companyName: 'कंपनी का नाम',
            title: 'शीर्षक',
            description: 'विवरण',
            location: 'स्थान',
            apply: 'अभी आवेदन करें',
            search: 'खोजें',
            save: 'बदलाव सहेजें',
            cancel: 'रद्द करें',
            language: 'भाषा',
            required: 'यह फ़ील्ड आवश्यक है।',
            footer: 'सर्वाधिकार सुरक्षित।',
            opportunities: 'नए अवसर खोजें',
            learnGrow: 'सीखें, आगे बढ़ें और अपना करियर बनाएँ',
            findInternship: 'इंटर्नशिप खोजें',
            viewDetails: 'विवरण देखें',
            noResults: 'कोई परिणाम नहीं मिला।',
            loading: 'लोड हो रहा है...',
            back: 'वापस',
            next: 'अगला',
            previous: 'पिछला',
            status: 'स्थिति',
            pending: 'लंबित',
            approved: 'स्वीकृत',
            rejected: 'अस्वीकृत',
            open: 'खुला',
            closed: 'बंद'
        },

        te: {
            home: 'హోమ్',
            login: 'లాగిన్',
            register: 'ఖాతా సృష్టించండి',
            logout: 'లాగ్ అవుట్',
            dashboard: 'డాష్‌బోర్డ్',
            welcome: 'InternSphere కు స్వాగతం',
            tagline: 'మీకు నచ్చిన ఇంటర్న్‌షిప్‌ను కనుగొని కెరీర్ ప్రారంభించండి.',
            getStarted: 'ప్రారంభించండి',
            exploreInternships: 'ఇంటర్న్‌షిప్‌లను చూడండి',
            email: 'ఈమెయిల్ చిరునామా',
            password: 'పాస్‌వర్డ్',
            confirmPassword: 'పాస్‌వర్డ్‌ను నిర్ధారించండి',
            firstName: 'మొదటి పేరు',
            lastName: 'చివరి పేరు',
            fullName: 'పూర్తి పేరు',
            age: 'వయస్సు',
            role: 'నమోదు రకం',
            student: 'విద్యార్థి',
            company: 'కంపెనీ',
            submit: 'సమర్పించండి',
            signIn: 'సైన్ ఇన్',
            signUp: 'సైన్ అప్',
            createAccount: 'ఖాతా సృష్టించండి',
            alreadyAccount: 'మీకు ఇప్పటికే ఖాతా ఉందా?',
            noAccount: 'మీకు ఖాతా లేదా?',
            internships: 'ఇంటర్న్‌షిప్‌లు',
            profile: 'నా ప్రొఫైల్',
            applications: 'నా దరఖాస్తులు',
            companyName: 'కంపెనీ పేరు',
            title: 'శీర్షిక',
            description: 'వివరణ',
            location: 'ప్రదేశం',
            apply: 'ఇప్పుడే దరఖాస్తు చేయండి',
            search: 'వెతకండి',
            save: 'మార్పులను సేవ్ చేయండి',
            cancel: 'రద్దు చేయండి',
            language: 'భాష',
            required: 'ఈ ఫీల్డ్ తప్పనిసరి.',
            footer: 'అన్ని హక్కులు ప్రత్యేకించబడ్డాయి.',
            opportunities: 'కొత్త అవకాశాలను కనుగొనండి',
            learnGrow: 'నేర్చుకోండి, ఎదగండి, కెరీర్ నిర్మించుకోండి',
            findInternship: 'ఇంటర్న్‌షిప్‌ను కనుగొనండి',
            viewDetails: 'వివరాలను చూడండి',
            noResults: 'ఫలితాలు కనుగొనబడలేదు.',
            loading: 'లోడ్ అవుతోంది...',
            back: 'వెనక్కి',
            next: 'తదుపరి',
            previous: 'మునుపటి',
            status: 'స్థితి',
            pending: 'పెండింగ్‌లో ఉంది',
            approved: 'ఆమోదించబడింది',
            rejected: 'తిరస్కరించబడింది',
            open: 'తెరిచి ఉంది',
            closed: 'మూసివేయబడింది'
        }
    };

    // Read saved language. English is used when no valid choice exists.
    function getSavedLanguage() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);

            if (saved && Object.prototype.hasOwnProperty.call(translations, saved)) {
                return saved;
            }
        } catch (error) {
            // Use English if browser storage is unavailable.
        }

        return DEFAULT_LANGUAGE;
    }

    // Save the selected language for future pages and visits.
    function saveLanguage(language) {
        try {
            localStorage.setItem(STORAGE_KEY, language);
        } catch (error) {
            // Language switching still works on the current page.
        }
    }

    function translatePage(language) {
        if (!Object.prototype.hasOwnProperty.call(translations, language)) {
            language = DEFAULT_LANGUAGE;
        }

        const dictionary = translations[language];

        document.documentElement.lang = language;

        // Translate text elements marked with data-i18n.
        document.querySelectorAll('[data-i18n]').forEach(function (element) {
            const key = element.getAttribute('data-i18n');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                // Preserve nested HTML such as icons or spans.
                const textNode = Array.from(element.childNodes).find(function (node) {
                    return node.nodeType === Node.TEXT_NODE &&
                        node.textContent.trim().length > 0;
                });

                if (textNode) {
                    textNode.textContent = dictionary[key];
                } else if (!element.querySelector('*')) {
                    element.textContent = dictionary[key];
                } else {
                    element.setAttribute('aria-label', dictionary[key]);
                }
            }
        });

        // Translate input placeholders.
        document.querySelectorAll('[data-i18n-placeholder]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-placeholder');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('placeholder', dictionary[key]);
            }
        });

        // Translate title attributes.
        document.querySelectorAll('[data-i18n-title]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-title');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('title', dictionary[key]);
            }
        });

        // Translate accessible labels.
        document.querySelectorAll('[data-i18n-aria-label]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-aria-label');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('aria-label', dictionary[key]);
            }
        });

        // Synchronize all language dropdowns.
        document.querySelectorAll('[data-language-selector]').forEach(function (selector) {
            selector.value = language;
        });

        saveLanguage(language);

        document.dispatchEvent(new CustomEvent('internsphere:languageChanged', {
            detail: { language: language }
        }));
    }

    // Public functions for other scripts if needed.
    window.InternSphereLanguage = {
        apply: translatePage,
        getCurrent: getSavedLanguage,
        getTranslations: function () {
            return translations;
        }
    };

    // Respond to language dropdown changes.
    document.addEventListener('change', function (event) {
        const target = event.target;

        if (target instanceof Element && target.matches('[data-language-selector]')) {
            translatePage(target.value);
        }
    });

    // Use the saved language when the page opens.
    function initializeLanguage() {
        translatePage(getSavedLanguage());
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeLanguage, { once: true });
    } else {
        initializeLanguage();
    }
})();

(function () {
    'use strict';

    const STORAGE_KEY = 'internsphere_language';
    const DEFAULT_LANGUAGE = 'en';

    const translations = {
        en: {
            home: 'Home',
            login: 'Login',
            register: 'Create Account',
            logout: 'Logout',
            dashboard: 'Dashboard',
            welcome: 'Welcome to InternSphere',
            tagline: 'Find your dream internship and start your career.',
            getStarted: 'Get Started',
            exploreInternships: 'Explore Internships',
            email: 'Email Address',
            password: 'Password',
            confirmPassword: 'Confirm Password',
            firstName: 'First Name',
            lastName: 'Last Name',
            fullName: 'Full Name',
            age: 'Age',
            role: 'Register As',
            student: 'Student',
            company: 'Company',
            submit: 'Submit',
            signIn: 'Sign In',
            signUp: 'Sign Up',
            createAccount: 'Create Account',
            alreadyAccount: 'Already have an account?',
            noAccount: "Don't have an account?",
            internships: 'Internships',
            profile: 'My Profile',
            applications: 'My Applications',
            companyName: 'Company Name',
            title: 'Title',
            description: 'Description',
            location: 'Location',
            apply: 'Apply Now',
            search: 'Search',
            save: 'Save Changes',
            cancel: 'Cancel',
            language: 'Language',
            required: 'This field is required.',
            footer: 'All rights reserved.',
            opportunities: 'Discover New Opportunities',
            learnGrow: 'Learn, Grow and Build Your Career',
            findInternship: 'Find Internships',
            viewDetails: 'View Details',
            noResults: 'No results found.',
            loading: 'Loading...',
            back: 'Back',
            next: 'Next',
            previous: 'Previous',
            status: 'Status',
            pending: 'Pending',
            approved: 'Approved',
            rejected: 'Rejected',
            open: 'Open',
            closed: 'Closed',

            eyebrow: 'CONNECT STUDENTS WITH CAREER OPPORTUNITIES',
            heroLine1: 'Find Internships.',
            heroLine2: 'Learn New Skills.',
            heroLine3: 'Build Your Future.',
            heroText: 'Discover exciting internships, learn valuable skills, gain real-world experience, and take the first step toward a successful career with InternSphere.',
            goDashboard: 'Go to Dashboard',
            portalName: 'Student Internship Portal',
            whyChoose: 'WHY CHOOSE INTERNSPHERE',
            featuresHeading: 'Connecting Talent with Opportunity.',
            featuresDescription: 'A smarter platform for students to discover career opportunities and for companies to connect with emerging talent.',
            feature1Title: 'Professional Profiles',
            feature1Text: 'Showcase your education, skills, projects, and resume in one place.',
            feature2Title: 'Career Opportunities',
            feature2Text: 'Discover internships that align with your skills and career goals.',
            feature3Title: 'Application Tracking',
            feature3Text: 'Monitor application updates and stay informed throughout the selection process.',
            feature4Title: 'Smart Recruitment',
            feature4Text: 'Help companies publish internship openings and connect with promising candidates.',
            footerText: 'College Internship Portal'
        },

        ta: {
            home: 'முகப்பு',
            login: 'உள்நுழை',
            register: 'கணக்கை உருவாக்கு',
            logout: 'வெளியேறு',
            dashboard: 'முகப்புப் பலகை',
            welcome: 'InternSphere-க்கு வரவேற்கிறோம்',
            tagline: 'உங்கள் கனவு இன்டர்ன்ஷிப்பைக் கண்டுபிடித்து தொழில் பயணத்தைத் தொடங்குங்கள்.',
            getStarted: 'தொடங்குங்கள்',
            exploreInternships: 'இன்டர்ன்ஷிப்புகளைப் பாருங்கள்',
            email: 'மின்னஞ்சல் முகவரி',
            password: 'கடவுச்சொல்',
            confirmPassword: 'கடவுச்சொல்லை உறுதிப்படுத்தவும்',
            firstName: 'முதல் பெயர்',
            lastName: 'கடைசி பெயர்',
            fullName: 'முழுப் பெயர்',
            age: 'வயது',
            role: 'பதிவு செய்யும் வகை',
            student: 'மாணவர்',
            company: 'நிறுவனம்',
            submit: 'சமர்ப்பிக்கவும்',
            signIn: 'உள்நுழைக',
            signUp: 'பதிவு செய்யவும்',
            createAccount: 'கணக்கை உருவாக்கு',
            alreadyAccount: 'ஏற்கனவே கணக்கு உள்ளதா?',
            noAccount: 'கணக்கு இல்லையா?',
            internships: 'இன்டர்ன்ஷிப்புகள்',
            profile: 'எனது சுயவிவரம்',
            applications: 'எனது விண்ணப்பங்கள்',
            companyName: 'நிறுவனத்தின் பெயர்',
            title: 'தலைப்பு',
            description: 'விளக்கம்',
            location: 'இடம்',
            apply: 'இப்போது விண்ணப்பிக்கவும்',
            search: 'தேடல்',
            save: 'மாற்றங்களைச் சேமி',
            cancel: 'ரத்து செய்',
            language: 'மொழி',
            required: 'இந்தப் புலத்தை நிரப்ப வேண்டும்.',
            footer: 'அனைத்து உரிமைகளும் பாதுகாக்கப்பட்டவை.',
            opportunities: 'புதிய வாய்ப்புகளைக் கண்டறியுங்கள்',
            learnGrow: 'கற்றுக்கொள்ளுங்கள், வளருங்கள், தொழிலை உருவாக்குங்கள்',
            findInternship: 'இன்டர்ன்ஷிப்பைக் கண்டறியுங்கள்',
            viewDetails: 'விவரங்களைப் பார்க்கவும்',
            noResults: 'முடிவுகள் எதுவும் இல்லை.',
            loading: 'ஏற்றப்படுகிறது...',
            back: 'பின்செல்',
            next: 'அடுத்து',
            previous: 'முந்தையது',
            status: 'நிலை',
            pending: 'நிலுவையில்',
            approved: 'அங்கீகரிக்கப்பட்டது',
            rejected: 'நிராகரிக்கப்பட்டது',
            open: 'திறந்துள்ளது',
            closed: 'மூடப்பட்டுள்ளது',

            eyebrow: 'மாணவர்களையும் தொழில் வாய்ப்புகளையும் இணைக்கிறோம்',
            heroLine1: 'இன்டர்ன்ஷிப்பைக் கண்டறியுங்கள்.',
            heroLine2: 'புதிய திறன்களைக் கற்றுக்கொள்ளுங்கள்.',
            heroLine3: 'உங்கள் எதிர்காலத்தை உருவாக்குங்கள்.',
            heroText: 'சிறந்த இன்டர்ன்ஷிப்புகளைக் கண்டறிந்து, மதிப்புமிக்க திறன்களைக் கற்று, நடைமுறை அனுபவம் பெற்று, InternSphere மூலம் உங்கள் தொழில் பயணத்தைத் தொடங்குங்கள்.',
            goDashboard: 'முகப்புப் பலகைக்குச் செல்லுங்கள்',
            portalName: 'மாணவர் இன்டர்ன்ஷிப் தளம்',
            whyChoose: 'ஏன் INTERNSPHERE-ஐ தேர்வு செய்ய வேண்டும்?',
            featuresHeading: 'திறமைகளையும் வாய்ப்புகளையும் இணைக்கிறோம்.',
            featuresDescription: 'மாணவர்கள் தொழில் வாய்ப்புகளைக் கண்டறியவும், நிறுவனங்கள் புதிய திறமையாளர்களைச் சந்திக்கவும் உதவும் சிறந்த தளம்.',
            feature1Title: 'தொழில்முறை சுயவிவரங்கள்',
            feature1Text: 'உங்கள் கல்வி, திறன்கள், திட்டங்கள் மற்றும் சுயவிவரத்தை ஒரே இடத்தில் காட்டுங்கள்.',
            feature2Title: 'தொழில் வாய்ப்புகள்',
            feature2Text: 'உங்கள் திறன்களுக்கும் தொழில் இலக்குகளுக்கும் ஏற்ற இன்டர்ன்ஷிப்புகளைக் கண்டறியுங்கள்.',
            feature3Title: 'விண்ணப்ப கண்காணிப்பு',
            feature3Text: 'விண்ணப்ப நிலையைப் பின்தொடர்ந்து தேர்வு செயல்முறை பற்றிய தகவல்களை அறியுங்கள்.',
            feature4Title: 'சிறந்த ஆட்சேர்ப்பு',
            feature4Text: 'நிறுவனங்கள் இன்டர்ன்ஷிப் வாய்ப்புகளை வெளியிட்டு திறமையான மாணவர்களைத் தேர்ந்தெடுக்க உதவுங்கள்.',
            footerText: 'கல்லூரி இன்டர்ன்ஷிப் தளம்'
        },

        hi: {
            home: 'होम',
            login: 'लॉगिन',
            register: 'खाता बनाएँ',
            logout: 'लॉगआउट',
            dashboard: 'डैशबोर्ड',
            welcome: 'InternSphere में आपका स्वागत है',
            tagline: 'अपनी पसंद की इंटर्नशिप खोजें और करियर शुरू करें।',
            getStarted: 'शुरू करें',
            exploreInternships: 'इंटर्नशिप देखें',
            email: 'ईमेल पता',
            password: 'पासवर्ड',
            confirmPassword: 'पासवर्ड की पुष्टि करें',
            firstName: 'पहला नाम',
            lastName: 'उपनाम',
            fullName: 'पूरा नाम',
            age: 'आयु',
            role: 'पंजीकरण का प्रकार',
            student: 'विद्यार्थी',
            company: 'कंपनी',
            submit: 'जमा करें',
            signIn: 'साइन इन',
            signUp: 'साइन अप',
            createAccount: 'खाता बनाएँ',
            alreadyAccount: 'क्या आपके पास पहले से खाता है?',
            noAccount: 'क्या आपके पास खाता नहीं है?',
            internships: 'इंटर्नशिप',
            profile: 'मेरी प्रोफ़ाइल',
            applications: 'मेरे आवेदन',
            companyName: 'कंपनी का नाम',
            title: 'शीर्षक',
            description: 'विवरण',
            location: 'स्थान',
            apply: 'अभी आवेदन करें',
            search: 'खोजें',
            save: 'बदलाव सहेजें',
            cancel: 'रद्द करें',
            language: 'भाषा',
            required: 'यह फ़ील्ड आवश्यक है।',
            footer: 'सर्वाधिकार सुरक्षित।',
            opportunities: 'नए अवसर खोजें',
            learnGrow: 'सीखें, आगे बढ़ें और अपना करियर बनाएँ',
            findInternship: 'इंटर्नशिप खोजें',
            viewDetails: 'विवरण देखें',
            noResults: 'कोई परिणाम नहीं मिला।',
            loading: 'लोड हो रहा है...',
            back: 'वापस',
            next: 'अगला',
            previous: 'पिछला',
            status: 'स्थिति',
            pending: 'लंबित',
            approved: 'स्वीकृत',
            rejected: 'अस्वीकृत',
            open: 'खुला',
            closed: 'बंद',

            eyebrow: 'छात्रों को करियर के अवसरों से जोड़ना',
            heroLine1: 'इंटर्नशिप खोजें।',
            heroLine2: 'नए कौशल सीखें।',
            heroLine3: 'अपना भविष्य बनाएँ।',
            heroText: 'रोमांचक इंटर्नशिप खोजें, उपयोगी कौशल सीखें और वास्तविक अनुभव प्राप्त करके InternSphere के साथ अपने करियर की शुरुआत करें।',
            goDashboard: 'डैशबोर्ड पर जाएँ',
            portalName: 'छात्र इंटर्नशिप पोर्टल',
            whyChoose: 'INTERNSPHERE क्यों चुनें?',
            featuresHeading: 'प्रतिभा और अवसरों को जोड़ना।',
            featuresDescription: 'छात्रों को करियर के अवसर खोजने और कंपनियों को नई प्रतिभाओं से जुड़ने में मदद करने वाला मंच।',
            feature1Title: 'प्रोफेशनल प्रोफ़ाइल',
            feature1Text: 'अपनी शिक्षा, कौशल, परियोजनाएँ और रिज़्यूमे एक ही जगह दिखाएँ।',
            feature2Title: 'करियर के अवसर',
            feature2Text: 'अपने कौशल और करियर लक्ष्यों के अनुसार इंटर्नशिप खोजें।',
            feature3Title: 'आवेदन ट्रैकिंग',
            feature3Text: 'अपने आवेदन की स्थिति और चयन प्रक्रिया के अपडेट देखें।',
            feature4Title: 'स्मार्ट भर्ती',
            feature4Text: 'कंपनियों को इंटर्नशिप प्रकाशित करने और योग्य उम्मीदवारों से जुड़ने में मदद करें।',
            footerText: 'कॉलेज इंटर्नशिप पोर्टल'
        },

        te: {
            home: 'హోమ్',
            login: 'లాగిన్',
            register: 'ఖాతా సృష్టించండి',
            logout: 'లాగ్ అవుట్',
            dashboard: 'డాష్‌బోర్డ్',
            welcome: 'InternSphere కు స్వాగతం',
            tagline: 'మీకు నచ్చిన ఇంటర్న్‌షిప్‌ను కనుగొని కెరీర్ ప్రారంభించండి.',
            getStarted: 'ప్రారంభించండి',
            exploreInternships: 'ఇంటర్న్‌షిప్‌లను చూడండి',
            email: 'ఈమెయిల్ చిరునామా',
            password: 'పాస్‌వర్డ్',
            confirmPassword: 'పాస్‌వర్డ్‌ను నిర్ధారించండి',
            firstName: 'మొదటి పేరు',
            lastName: 'చివరి పేరు',
            fullName: 'పూర్తి పేరు',
            age: 'వయస్సు',
            role: 'నమోదు రకం',
            student: 'విద్యార్థి',
            company: 'కంపెనీ',
            submit: 'సమర్పించండి',
            signIn: 'సైన్ ఇన్',
            signUp: 'సైన్ అప్',
            createAccount: 'ఖాతా సృష్టించండి',
            alreadyAccount: 'మీకు ఇప్పటికే ఖాతా ఉందా?',
            noAccount: 'మీకు ఖాతా లేదా?',
            internships: 'ఇంటర్న్‌షిప్‌లు',
            profile: 'నా ప్రొఫైల్',
            applications: 'నా దరఖాస్తులు',
            companyName: 'కంపెనీ పేరు',
            title: 'శీర్షిక',
            description: 'వివరణ',
            location: 'ప్రదేశం',
            apply: 'ఇప్పుడే దరఖాస్తు చేయండి',
            search: 'వెతకండి',
            save: 'మార్పులను సేవ్ చేయండి',
            cancel: 'రద్దు చేయండి',
            language: 'భాష',
            required: 'ఈ ఫీల్డ్ తప్పనిసరి.',
            footer: 'అన్ని హక్కులు ప్రత్యేకించబడ్డాయి.',
            opportunities: 'కొత్త అవకాశాలను కనుగొనండి',
            learnGrow: 'నేర్చుకోండి, ఎదగండి, కెరీర్ నిర్మించుకోండి',
            findInternship: 'ఇంటర్న్‌షిప్‌ను కనుగొనండి',
            viewDetails: 'వివరాలను చూడండి',
            noResults: 'ఫలితాలు కనుగొనబడలేదు.',
            loading: 'లోడ్ అవుతోంది...',
            back: 'వెనక్కి',
            next: 'తదుపరి',
            previous: 'మునుపటి',
            status: 'స్థితి',
            pending: 'పెండింగ్‌లో ఉంది',
            approved: 'ఆమోదించబడింది',
            rejected: 'తిరస్కరించబడింది',
            open: 'తెరిచి ఉంది',
            closed: 'మూసివేయబడింది',

            eyebrow: 'విద్యార్థులను కెరీర్ అవకాశాలతో అనుసంధానించడం',
            heroLine1: 'ఇంటర్న్‌షిప్‌లను కనుగొనండి.',
            heroLine2: 'కొత్త నైపుణ్యాలను నేర్చుకోండి.',
            heroLine3: 'మీ భవిష్యత్తును నిర్మించుకోండి.',
            heroText: 'మంచి ఇంటర్న్‌షిప్‌లను కనుగొని, ఉపయోగకరమైన నైపుణ్యాలను నేర్చుకుని, వాస్తవ అనుభవాన్ని పొంది InternSphereతో మీ కెరీర్‌ను ప్రారంభించండి.',
            goDashboard: 'డాష్‌బోర్డ్‌కు వెళ్లండి',
            portalName: 'విద్యార్థుల ఇంటర్న్‌షిప్ పోర్టల్',
            whyChoose: 'INTERNSPHEREనే ఎందుకు ఎంచుకోవాలి?',
            featuresHeading: 'ప్రతిభను అవకాశాలతో కలుపుతుంది.',
            featuresDescription: 'విద్యార్థులు కెరీర్ అవకాశాలను కనుగొనడానికి, కంపెనీలు కొత్త ప్రతిభావంతులను చేరుకోవడానికి సహాయపడే వేదిక.',
            feature1Title: 'వృత్తిపరమైన ప్రొఫైల్‌లు',
            feature1Text: 'మీ విద్య, నైపుణ్యాలు, ప్రాజెక్టులు, రెజ్యూమేను ఒకే చోట చూపించండి.',
            feature2Title: 'కెరీర్ అవకాశాలు',
            feature2Text: 'మీ నైపుణ్యాలు మరియు కెరీర్ లక్ష్యాలకు సరిపోయే ఇంటర్న్‌షిప్‌లను కనుగొనండి.',
            feature3Title: 'దరఖాస్తుల ట్రాకింగ్',
            feature3Text: 'మీ దరఖాస్తుల స్థితిని మరియు ఎంపిక ప్రక్రియ నవీకరణలను తెలుసుకోండి.',
            feature4Title: 'స్మార్ట్ నియామకం',
            feature4Text: 'కంపెనీలు ఇంటర్న్‌షిప్‌లను ప్రచురించి ప్రతిభావంతులైన అభ్యర్థులను చేరుకోవడంలో సహాయపడండి.',
            footerText: 'కళాశాల ఇంటర్న్‌షిప్ పోర్టల్'
        }
    };

    function getSavedLanguage() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);

            if (saved && Object.prototype.hasOwnProperty.call(translations, saved)) {
                return saved;
            }
        } catch (error) {
            // Storage may be unavailable.
        }

        return DEFAULT_LANGUAGE;
    }

    function saveLanguage(language) {
        try {
            localStorage.setItem(STORAGE_KEY, language);
        } catch (error) {
            // Keep the current page usable if storage is blocked.
        }
    }

    function translatePage(language) {
        if (!Object.prototype.hasOwnProperty.call(translations, language)) {
            language = DEFAULT_LANGUAGE;
        }

        const dictionary = translations[language];

        document.documentElement.lang = language;

        // Translate text without removing child icons or nested HTML.
        document.querySelectorAll('[data-i18n]').forEach(function (element) {
            const key = element.getAttribute('data-i18n');

            if (!Object.prototype.hasOwnProperty.call(dictionary, key)) {
                return;
            }

            const textNode = Array.from(element.childNodes).find(function (node) {
                return node.nodeType === Node.TEXT_NODE &&
                    node.textContent.trim().length > 0;
            });

            if (textNode) {
                textNode.textContent = dictionary[key];
            } else if (!element.querySelector('*')) {
                element.textContent = dictionary[key];
            } else {
                element.setAttribute('aria-label', dictionary[key]);
            }
        });

        // Translate placeholders.
        document.querySelectorAll('[data-i18n-placeholder]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-placeholder');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('placeholder', dictionary[key]);
            }
        });

        // Translate title attributes.
        document.querySelectorAll('[data-i18n-title]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-title');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('title', dictionary[key]);
            }
        });

        // Translate accessible labels.
        document.querySelectorAll('[data-i18n-aria-label]').forEach(function (element) {
            const key = element.getAttribute('data-i18n-aria-label');

            if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
                element.setAttribute('aria-label', dictionary[key]);
            }
        });

        // Keep every language dropdown synchronized.
        document.querySelectorAll('[data-language-selector]').forEach(function (selector) {
            selector.value = language;
        });

        saveLanguage(language);

        document.dispatchEvent(new CustomEvent('internsphere:languageChanged', {
            detail: { language: language }
        }));
    }

    window.InternSphereLanguage = {
        apply: translatePage,
        getCurrent: getSavedLanguage,
        getTranslations: function () {
            return translations;
        }
    };

    // Change the page language when the user selects an option.
    document.addEventListener('change', function (event) {
        const target = event.target;

        if (target instanceof Element && target.matches('[data-language-selector]')) {
            translatePage(target.value);
        }
    });

    function initializeLanguage() {
        translatePage(getSavedLanguage());
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeLanguage, { once: true });
    } else {
        initializeLanguage();
    }
})();
