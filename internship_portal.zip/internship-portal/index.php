
<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();

$dashboardUrl = '';

if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'] ?? '';

    if ($role === 'student') {
        $dashboardUrl = 'student/dashboard.php';
    } elseif ($role === 'company') {
        $dashboardUrl = 'company/dashboard.php';
    }
}

$heroImageFile = __DIR__ . '/css/images/internsphere-welcome.png';
$heroImageUrl = 'css/images/internsphere-welcome.png';
$heroImageExists = is_file($heroImageFile);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <meta name="description" content="InternSphere helps students discover internships, build professional profiles, develop skills, and manage internship applications.">

    <link rel="stylesheet" href="css/style.css?v=10">

    <style>
        .navbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 22px;
        }

        .language-selector {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            margin: 0;
            padding: 5px 10px;
            border: 1px solid rgba(124, 92, 255, .45);
            border-radius: 22px;
            background: rgba(20, 20, 40, .9);
            white-space: nowrap;
        }

        .language-selector .language-icon {
            font-size: 15px;
        }

        .language-selector select {
            width: auto;
            max-width: 150px;
            padding: 5px 2px;
            border: none;
            outline: none;
            background: transparent;
            color: #f8fafc;
            font-size: 12px;
            cursor: pointer;
        }

        .language-selector select option {
            color: #111827;
            background: #fff;
        }

        @media (max-width: 760px) {
            .navbar {
                align-items: flex-start;
                flex-wrap: wrap;
            }

            .nav-links {
                justify-content: flex-start;
                flex-wrap: wrap;
                gap: 12px;
            }

            .language-selector {
                margin: 3px 0;
            }
        }
    </style>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar">

        <a class="logo" href="index.php" aria-label="InternSphere Home">
            Intern<span>Sphere</span>
        </a>

        <div class="nav-links">

            <a href="index.php" data-i18n="home">Home</a>

            <div class="language-selector">
                <span class="language-icon" aria-hidden="true">🌐</span>

                <label for="languageSelect" style="display:none;">
                    Language
                </label>

                <select id="languageSelect" data-language-selector
                        aria-label="Select language">
                    <option value="en">Language: English</option>
                    <option value="ta">தமிழ் (Tamil)</option>
                    <option value="hi">हिन्दी (Hindi)</option>
                    <option value="te">తెలుగు (Telugu)</option>
                </select>
            </div>

            <?php if (isset($_SESSION['user_id'])): ?>

                <?php if ($dashboardUrl !== ''): ?>
                    <a
                        href="<?= htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') ?>"
                        data-i18n="dashboard"
                    >Dashboard</a>
                <?php endif; ?>

                <a href="logout.php" data-i18n="logout">Logout</a>

            <?php else: ?>

                <a href="login.php" data-i18n="signIn">Sign In</a>

                <a class="nav-button" href="register.php"
                   data-i18n="createAccount">Create Account</a>

            <?php endif; ?>

        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">

        <div class="hero-content">

            <p class="eyebrow" data-i18n="eyebrow">
                CONNECT STUDENTS WITH CAREER OPPORTUNITIES
            </p>

            <h1>
                <span class="hero-line" data-i18n="heroLine1">Find Internships.</span><br>
                <span data-i18n="heroLine2">Learn New Skills.</span><br>
                <span class="hero-line" data-i18n="heroLine3">Build Your Future.</span>
            </h1>

            <p class="hero-text" data-i18n="heroText">
                Discover exciting internships, learn valuable skills,
                gain real-world experience, and take the first step
                toward a successful career with InternSphere.
            </p>

            <div class="hero-buttons">

                <?php if (isset($_SESSION['user_id'])): ?>

                    <?php if ($dashboardUrl !== ''): ?>
                        <a class="btn primary"
                           href="<?= htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') ?>"
                           data-i18n="goDashboard">
                            Go to Dashboard
                        </a>
                    <?php endif; ?>

                <?php else: ?>

                    <a class="btn primary" href="register.php"
                       data-i18n="getStarted">Get Started</a>

                    <a class="btn secondary" href="login.php"
                       data-i18n="signIn">Sign In</a>

                <?php endif; ?>

            </div>
        </div>

        <!-- Hero Image -->
        <div class="hero-image">

            <?php if ($heroImageExists): ?>

                <img
                    src="<?= htmlspecialchars($heroImageUrl, ENT_QUOTES, 'UTF-8') ?>"
                    alt="Welcome to InternSphere - Student Internship Portal"
                    loading="eager"
                >

            <?php else: ?>

                <div class="hero-image-placeholder">
                    <p>InternSphere</p>
                    <p data-i18n="portalName">Student Internship Portal</p>
                    <small>
                        Image file not found. Check:
                        css/images/internsphere-welcome.png
                    </small>
                </div>

            <?php endif; ?>

        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">

        <div class="section-heading">

            <span class="eyebrow" data-i18n="whyChoose">
                WHY CHOOSE INTERNSPHERE
            </span>

            <h2 data-i18n="featuresHeading">
                Connecting Talent with Opportunity.
            </h2>

            <p data-i18n="featuresDescription">
                A smarter platform for students to discover career
                opportunities and for companies to connect with
                emerging talent.
            </p>

        </div>

        <div class="features-grid">

            <div class="feature-card">
                <span class="feature-number">01</span>

                <h3 data-i18n="feature1Title">Professional Profiles</h3>

                <p data-i18n="feature1Text">
                    Showcase your education, skills, projects, and resume in one place.
                </p>
            </div>

            <div class="feature-card">
                <span class="feature-number">02</span>

                <h3 data-i18n="feature2Title">Career Opportunities</h3>

                <p data-i18n="feature2Text">
                    Discover internships that align with your skills and career goals.
                </p>
            </div>

            <div class="feature-card">
                <span class="feature-number">03</span>

                <h3 data-i18n="feature3Title">Application Tracking</h3>

                <p data-i18n="feature3Text">
                    Monitor application updates and stay informed throughout the selection process.
                </p>
            </div>

            <div class="feature-card">
                <span class="feature-number">04</span>

                <h3 data-i18n="feature4Title">Smart Recruitment</h3>

                <p data-i18n="feature4Text">
                    Help companies publish internship openings and connect with promising candidates.
                </p>
            </div>

        </div>
    </section>

    <!-- Footer -->
    <footer>
        &copy; <?= date('Y') ?> InternSphere ·
        <span data-i18n="footerText">College Internship Portal</span>
    </footer>

    <!-- Local language system; no Google Translate -->
    <script src="js/language.js"></script>
    <script src="js/validation.js"></script>

</body>
</html>
