
<?php

// Project: InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL

// 1. Start the current session
session_start();

// 2. Clear all session variables
$_SESSION = [];

// 3. Check whether sessions use cookies
if (ini_get('session.use_cookies')) {

    // 4. Get the current session cookie settings
    $p = session_get_cookie_params();

    // 5. Expire the session cookie
    setcookie(
        session_name(),
        '',
        [
            'expires'  => time() - 42000,
            'path'     => $p['path'],
            'domain'   => $p['domain'],
            'secure'   => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => $p['samesite'] ?? 'Lax'
        ]
    );
}

// 6. Destroy the current session
session_destroy();

// 7. Redirect the user to the home page
header('Location: index.php');

// 8. Stop executing the script
exit;

?>
