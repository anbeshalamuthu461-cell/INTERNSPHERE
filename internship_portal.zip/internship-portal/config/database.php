
<?php
/**
 * InternSphere - Storage Layer
 *
 * Project Title:
 * InternSphere: A Web-Based Student Internship and Recruitment
 * Management System Using PHP and MySQL
 *
 * This project uses a JSON datastore for storing portal information
 * when the PHP runtime does not support the mysqli extension.
 *
 * The MySQL connection details below are retained for reference
 * if MySQL is enabled in a future deployment.
 */

// --------------------------------------------------
// 1. Database Configuration
// --------------------------------------------------

const DB_HOST = 'db01.dbhost.dev';
const DB_PORT = 5051;
const DB_NAME = 'db_455k2fguz';
const DB_USER = 'user_455k2fguz';
const DB_PASS = 'p455k2fguz';

// --------------------------------------------------
// 2. JSON Storage Configuration
// --------------------------------------------------

define('DATA_DIR', dirname(__DIR__, 2) . '/internhub_data');
define('DATA_FILE', DATA_DIR . '/portal.json');

// --------------------------------------------------
// 3. Default Database Structure
// --------------------------------------------------

function db_default(): array {
    return [
        'users' => [],
        'students' => [],
        'companies' => [],
        'internships' => [],
        'applications' => [],
        'counters' => [
            'users' => 0,
            'students' => 0,
            'companies' => 0,
            'internships' => 0,
            'applications' => 0,
        ],
    ];
}

// --------------------------------------------------
// 4. Initialize JSON Storage
// --------------------------------------------------

function db_boot(): void {
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0775, true);
    }

    if (!file_exists(DATA_FILE)) {
        @file_put_contents(
            DATA_FILE,
            json_encode(db_default(), JSON_PRETTY_PRINT),
            LOCK_EX
        );
    }
}

// --------------------------------------------------
// 5. Load Stored Data
// --------------------------------------------------

function db_load(): array {
    db_boot();

    $raw = @file_get_contents(DATA_FILE);
    $data = $raw ? json_decode($raw, true) : null;

    if (!is_array($data)) {
        $data = db_default();
    }

    foreach (db_default() as $key => $value) {
        if (!array_key_exists($key, $data) || !is_array($data[$key])) {
            $data[$key] = $value;
        }
    }

    return $data;
}

// --------------------------------------------------
// 6. Save Stored Data
// --------------------------------------------------

function db_save(array $data): bool {
    db_boot();

    $tmp = DATA_FILE . '.tmp';

    $json = json_encode(
        $data,
        JSON_PRETTY_PRINT |
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    if ($json === false) {
        return false;
    }

    if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
        return false;
    }

    return @rename($tmp, DATA_FILE);
}

// --------------------------------------------------
// 7. Generate New Record IDs
// --------------------------------------------------

function db_next_id(array &$data, string $table): int {
    $data['counters'][$table] =
        (int) ($data['counters'][$table] ?? 0) + 1;

    return $data['counters'][$table];
}

// --------------------------------------------------
// 8. Get Current Date and Time
// --------------------------------------------------

function db_now(): string {
    return date('Y-m-d H:i:s');
}

// --------------------------------------------------
// 9. Find User by Email
// --------------------------------------------------

function db_find_user_by_email(
    array $data,
    string $email
): ?array {
    foreach ($data['users'] as $user) {
        if (
            strcasecmp(
                (string) ($user['email'] ?? ''),
                $email
            ) === 0
        ) {
            return $user;
        }
    }

    return null;
}

// --------------------------------------------------
// 10. Get User by ID
// --------------------------------------------------

function db_user(array $data, int $id): ?array {
    foreach ($data['users'] as $user) {
        if ((int) $user['id'] === $id) {
            return $user;
        }
    }

    return null;
}

// --------------------------------------------------
// 11. Get Student by User ID
// --------------------------------------------------

function db_student_by_user(
    array $data,
    int $userId
): ?array {
    foreach ($data['students'] as $row) {
        if ((int) $row['user_id'] === $userId) {
            return $row;
        }
    }

    return null;
}

// --------------------------------------------------
// 12. Get Company by User ID
// --------------------------------------------------

function db_company_by_user(
    array $data,
    int $userId
): ?array {
    foreach ($data['companies'] as $row) {
        if ((int) $row['user_id'] === $userId) {
            return $row;
        }
    }

    return null;
}

// --------------------------------------------------
// 13. Get Company by ID
// --------------------------------------------------

function db_company(array $data, int $id): ?array {
    foreach ($data['companies'] as $row) {
        if ((int) $row['id'] === $id) {
            return $row;
        }
    }

    return null;
}

// --------------------------------------------------
// 14. Get Internship by ID
// --------------------------------------------------

function db_internship(array $data, int $id): ?array {
    foreach ($data['internships'] as $row) {
        if ((int) $row['id'] === $id) {
            return $row;
        }
    }

    return null;
}

// --------------------------------------------------
// 15. Sort Records by Newest First
// --------------------------------------------------

function db_sort_newest(
    array &$rows,
    string $field = 'created_at'
): void {
    usort($rows, function ($a, $b) use ($field) {
        return strcmp(
            (string) ($b[$field] ?? ''),
            (string) ($a[$field] ?? '')
        );
    });
}

// --------------------------------------------------
// 16. Safely Escape Output
// --------------------------------------------------

function e($value): string {
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

// --------------------------------------------------
// 17. Set Flash Notification
// --------------------------------------------------

function flash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

// --------------------------------------------------
// 18. Retrieve Flash Notification
// --------------------------------------------------

function take_flash(): ?array {
    $flash = $_SESSION['flash'] ?? null;

    unset($_SESSION['flash']);

    return $flash;
}

// --------------------------------------------------
// 19. Check User Role and Access
// --------------------------------------------------

function require_role(
    string $role,
    string $loginPath = '../login.php'
): void {
    if (
        !isset($_SESSION['user_id']) ||
        ($_SESSION['role'] ?? '') !== $role
    ) {
        header('Location: ' . $loginPath);
        exit;
    }
}

// --------------------------------------------------
// 20. Format Application or Internship Status
// --------------------------------------------------

function status_class(string $status): string {
    return strtolower(
        str_replace(' ', '-', $status)
    );
}

?>
