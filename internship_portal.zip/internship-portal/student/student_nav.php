
<nav class="navbar dashboard-nav">

    <!-- InternSphere Logo -->
    <a class="logo" href="dashboard.php">
        Intern<span>Sphere</span>
    </a>

    <!-- Navigation Links -->
    <div class="nav-links">

        <a href="dashboard.php">
            Dashboard
        </a>

        <a href="profile.php">
            Profile
        </a>

        <a href="internships.php">
            Internships
        </a>

        <a href="applications.php">
            Applications
        </a>

        <!-- Logout Button -->
        <a href="../logout.php" class="logout-btn">
            Logout
        </a>

    </div>

</nav>
