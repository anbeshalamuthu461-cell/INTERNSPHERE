
<?php
// 1. Start the session
session_start();

// 2. Connect to the database
require_once __DIR__ . '/../config/database.php';

// 3. Allow student accounts only
require_role('student');

// 4. Load database data
$data = db_load();

// 5. Get the logged-in student's details
$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

// 6. Get the student ID
$sid = (int) ($student['id'] ?? 0);

// 7. Initialize the application list
$rows = [];

// 8. Find applications belonging to this student
foreach ($data['applications'] as $a) {

    // Skip applications belonging to other students
    if ((int) $a['student_id'] !== $sid) {
        continue;
    }

    // 9. Get the internship details
    $i = db_internship(
        $data,
        (int) $a['internship_id']
    );

    // Skip if the internship no longer exists
    if (!$i) {
        continue;
    }

    // 10. Get the company details
    $c = db_company(
        $data,
        (int) $i['company_id']
    );

    // 11. Add internship and company names
    $a['title'] = $i['title'] ?? 'Internship';
    $a['company_name'] = $c['company_name'] ?? 'Unknown Company';

    // 12. Add application to the display list
    $rows[] = $a;
}

// 13. Sort applications by newest first
usort(
    $rows,
    fn($a, $b) => strcmp(
        $b['applied_at'] ?? '',
        $a['applied_at'] ?? ''
    )
);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- 14. Basic page settings -->
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- 15. Updated InternSphere project title -->
    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <!-- 16. Load the website stylesheet -->
    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <!-- 17. Page-specific styling -->
    <style>
        .applications-page {
            max-width: 1200px;
            margin: 0 auto;
        }

        .applications-heading {
            margin-bottom: 28px;
        }

        .applications-heading h1 {
            margin-bottom: 12px;
        }

        .applications-heading p {
            line-height: 1.7;
        }

        .applications-table-card {
            width: 100%;
            overflow-x: auto;
            border-radius: 14px;
        }

        .applications-table-card table {
            width: 100%;
            border-collapse: collapse;
        }

        .applications-table-card th,
        .applications-table-card td {
            padding: 16px;
            text-align: left;
            vertical-align: middle;
        }

        .applications-table-card td strong {
            display: inline-block;
            overflow-wrap: anywhere;
        }

        .applications-table-card .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            white-space: nowrap;
        }

        .applications-empty-link {
            color: #22d3ee;
            text-decoration: none;
            font-weight: 600;
        }

        .applications-empty-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .applications-heading h1 {
                font-size: 27px;
            }

            .applications-table-card th,
            .applications-table-card td {
                padding: 12px;
            }
        }
    </style>

</head>

<body>

    <!-- 18. Display student navigation -->
    <?php include 'student_nav.php'; ?>

    <main class="dashboard applications-page">

        <!-- 19. Page heading -->
        <div class="page-heading applications-heading">

            <div>
                <p class="eyebrow">
                    APPLICATION TRACKER
                </p>

                <h1>My Applications.</h1>

                <p>
                    Track your internship applications, review their
                    current status, and stay informed about your
                    career opportunities.
                </p>
            </div>

        </div>

        <!-- 20. Applications table -->
        <div class="table-card applications-table-card">

            <table>

                <thead>
                    <tr>
                        <th>Internship</th>
                        <th>Company</th>
                        <th>Applied Date</th>
                        <th>Application Status</th>
                    </tr>
                </thead>

                <tbody>

                    <!-- 21. Show a message if there are no applications -->
                    <?php if (empty($rows)): ?>

                        <tr>
                            <td colspan="4" class="empty">

                                <p>
                                    You haven't applied for any internships yet.
                                </p>

                                <a
                                    href="internships.php"
                                    class="applications-empty-link"
                                >
                                    Browse Internships →
                                </a>

                            </td>
                        </tr>

                    <?php else: ?>

                        <!-- 22. Display each application -->
                        <?php foreach ($rows as $r): ?>

                            <tr>

                                <td>
                                    <strong>
                                        <?= e($r['title']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= e($r['company_name']) ?>
                                </td>

                                <td>
                                    <?php
                                    $timestamp = strtotime(
                                        $r['applied_at'] ?? ''
                                    );
                                    ?>

                                    <?= $timestamp
                                        ? e(date('d M Y', $timestamp))
                                        : 'Not available'
                                    ?>
                                </td>

                                <td>
                                    <span class="status <?= e(status_class($r['status'] ?? '')) ?>">
                                        <?= e($r['status'] ?? 'Pending') ?>
                                    </span>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>
