
<?php
// 1. Start the session
session_start();

// 2. Connect to the database
require_once __DIR__ . '/../config/database.php';

// 3. Allow only student accounts
require_role('student');

// 4. Load database information
$data = db_load();

// 5. Get the internship ID from the URL
$id = (int) ($_GET['id'] ?? 0);

// 6. Get internship details
$internship = db_internship($data, $id);

// 7. Initialize message variables
$message = '';
$messageType = 'success';

// 8. Get the logged-in student's details
$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

// 9. Get student ID
$sid = (int) ($student['id'] ?? 0);

// 10. Check whether the student already applied
$already = false;

if ($internship) {
    foreach ($data['applications'] as $a) {
        if (
            (int) $a['student_id'] === $sid &&
            (int) $a['internship_id'] === $id
        ) {
            $already = true;
            break;
        }
    }
}

// 11. Process the application form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!$internship) {
        $message = 'Internship not found.';
        $messageType = 'error';

    } elseif (($internship['status'] ?? '') !== 'Open') {
        $message = 'This internship is no longer accepting applications.';
        $messageType = 'error';

    } elseif ($already) {
        $message = 'You have already applied for this internship.';
        $messageType = 'error';

    } elseif (!$student || $sid <= 0) {
        $message = 'Student profile not found.';
        $messageType = 'error';

    } else {
        // Create a new application
        $data['applications'][] = [
            'id' => db_next_id($data, 'applications'),
            'student_id' => $sid,
            'internship_id' => $id,
            'status' => 'Applied',
            'applied_at' => db_now()
        ];

        // Save application
        if (db_save($data)) {
            $message = 'Application submitted successfully.';
            $already = true;
        } else {
            $message = 'Could not save your application.';
            $messageType = 'error';
        }
    }
}

// 12. Get company details
$company = $internship
    ? db_company($data, (int) $internship['company_id'])
    : null;

// 13. Check whether internship is open
$isOpen = $internship
    && ($internship['status'] ?? '') === 'Open';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- 14. Page configuration -->
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- 15. Updated InternSphere project title -->
    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <!-- 16. Load main stylesheet -->
    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <!-- 17. Page-specific styling -->
    <style>
        .apply-page {
            max-width: 850px;
            margin: 0 auto;
        }

        .apply-heading {
            margin-bottom: 25px;
        }

        .apply-detail-card {
            padding: 30px;
            border-radius: 18px;
        }

        .apply-detail-card h1 {
            margin-top: 18px;
            margin-bottom: 10px;
            overflow-wrap: anywhere;
        }

        .apply-company-name {
            margin-bottom: 22px;
        }

        .apply-description {
            line-height: 1.8;
            overflow-wrap: anywhere;
        }

        .apply-detail-info {
            margin: 24px 0;
            padding: 18px;
            border-radius: 12px;
        }

        .apply-detail-info p {
            line-height: 1.7;
            margin: 10px 0;
        }

        .apply-status {
            display: inline-block;
            padding: 7px 13px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
        }

        .apply-status.open {
            background: #dcfce7;
            color: #166534;
        }

        .apply-status.closed {
            background: #fee2e2;
            color: #991b1b;
        }

        .apply-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            align-items: center;
            margin-top: 22px;
        }

        .apply-back-link {
            text-decoration: none;
            font-weight: 600;
        }

        @media (max-width: 600px) {
            .apply-detail-card {
                padding: 20px;
            }

            .apply-detail-card h1 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

    <!-- 18. Display student navigation -->
    <?php include 'student_nav.php'; ?>

    <main class="dashboard narrow apply-page">

        <!-- 19. Page heading -->
        <div class="page-heading apply-heading">
            <div>
                <p class="eyebrow">CAREER OPPORTUNITY</p>

                <h1>Internship Details</h1>

                <p>
                    Explore the role, review the requirements,
                    and submit your application.
                </p>
            </div>
        </div>

        <!-- 20. Check whether internship and company exist -->
        <?php if (!$internship || !$company): ?>

            <div class="alert error">
                Internship not found. It may have been removed
                or the link may be invalid.
            </div>

            <p>
                <a href="internships.php" class="apply-back-link">
                    ← Browse Internships
                </a>
            </p>

        <?php else: ?>

            <!-- 21. Display internship information -->
            <div class="detail-card apply-detail-card">

                <span class="apply-status <?= $isOpen ? 'open' : 'closed' ?>">
                    <?= $isOpen ? 'Open for Applications' : 'Closed' ?>
                </span>

                <h1>
                    <?= e($internship['title'] ?? 'Internship') ?>
                </h1>

                <h3 class="apply-company-name">
                    <?= e($company['company_name'] ?? 'Unknown Company') ?>
                </h3>

                <div class="apply-description">
                    <?= nl2br(e(
                        $internship['description']
                        ?? 'No description available.'
                    )) ?>
                </div>

                <!-- Internship details -->
                <div class="detail-info apply-detail-info">

                    <p>
                        <strong>Location:</strong>
                        <?= e($internship['location'] ?? 'Not specified') ?>
                    </p>

                    <p>
                        <strong>Required Skills:</strong>
                        <?= e($internship['skills'] ?: 'Not specified') ?>
                    </p>

                    <p>
                        <strong>Duration:</strong>
                        <?= e($internship['duration'] ?: 'Not specified') ?>
                    </p>

                    <p>
                        <strong>Stipend:</strong>
                        <?= e($internship['stipend'] ?: 'Not specified') ?>
                    </p>

                </div>

                <!-- 22. Display application messages -->
                <?php if ($message !== ''): ?>
                    <div class="alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
                        <?= e($message) ?>
                    </div>
                <?php endif; ?>

                <!-- 23. Application actions -->
                <div class="apply-actions">

                    <?php if ($already): ?>

                        <p>
                            You have already applied for this internship.
                        </p>

                    <?php elseif (!$isOpen): ?>

                        <p>
                            Applications are currently closed for this internship.
                        </p>

                    <?php else: ?>

                        <form method="POST">
                            <button class="btn primary" type="submit">
                                Apply Now
                            </button>
                        </form>

                    <?php endif; ?>

                    <a
                        href="internships.php"
                        class="apply-back-link"
                    >
                        Browse More Internships
                    </a>

                </div>

            </div>

        <?php endif; ?>

    </main>

</body>
</html>
