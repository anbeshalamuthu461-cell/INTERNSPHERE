
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();

$student = db_student_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$sid = (int) ($student['id'] ?? 0);

$apps = array_values(
    array_filter(
        $data['applications'],
        fn($a) => (int) $a['student_id'] === $sid
    )
);

$short = count(
    array_filter(
        $apps,
        fn($a) => ($a['status'] ?? '') === 'Shortlisted'
    )
);

$open = count(
    array_filter(
        $data['internships'],
        fn($i) => ($i['status'] ?? '') === 'Open'
    )
);

$flash = take_flash();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- Updated InternSphere project title -->
    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        /* Gold Logout Button */
        .nav-links a.logout-btn {
            display: inline-block;
            background: linear-gradient(135deg, #ffe878, #ffb927);
            color: #111827 !important;
            padding: 10px 18px;
            border-radius: 10px;
            font-weight: 700;
            text-decoration: none;
            transition: all 0.25s ease;
        }

        .nav-links a.logout-btn:hover {
            background: linear-gradient(135deg, #ffdc55, #f5a900);
            color: #000 !important;
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(255, 190, 40, 0.25);
        }

        .dashboard {
            width: min(1150px, 92%);
            margin: 0 auto;
            padding: 48px 0;
        }

        .page-heading {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
            margin-bottom: 30px;
        }

        .page-heading h1 {
            margin: 12px 0;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .stat-card {
            padding: 25px;
            border-radius: 19px;
        }

        .stat-card span {
            display: block;
            margin-bottom: 12px;
        }

        .stat-card strong {
            font-size: 38px;
        }

        .quick-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
        }

        .quick-card {
            display: block;
            padding: 25px;
            border-radius: 19px;
            text-decoration: none;
            transition: transform 0.2s ease;
        }

        .quick-card:hover {
            transform: translateY(-4px);
        }

        .quick-card h3 {
            margin-top: 0;
        }

        .quick-card p {
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .page-heading {
                align-items: flex-start;
                flex-direction: column;
            }

            .stats-grid,
            .quick-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

    <?php include 'student_nav.php'; ?>

    <main class="dashboard">

        <!-- Dashboard Welcome -->
        <div class="page-heading">

            <div>
                <p class="eyebrow">CAREER DASHBOARD</p>

                <h1>
                    Hi, <?= e($_SESSION['name'] ?? 'Student') ?>.
                </h1>

                <p>
                    Stay informed about your applications, manage your professional
                    profile, and discover new career opportunities.
                </p>
            </div>

            <a class="btn primary" href="internships.php">
                Explore internships
            </a>

        </div>

        <!-- Notifications -->
        <?php if ($flash): ?>

            <div class="alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : 'error' ?>">
                <?= e($flash['message'] ?? '') ?>
            </div>

        <?php endif; ?>

        <!-- Dashboard Statistics -->
        <div class="stats-grid">

            <div class="stat-card">
                <span>Applications</span>
                <strong><?= count($apps) ?></strong>
            </div>

            <div class="stat-card">
                <span>Shortlisted</span>
                <strong><?= $short ?></strong>
            </div>

            <div class="stat-card">
                <span>Open roles</span>
                <strong><?= $open ?></strong>
            </div>

        </div>

        <!-- Quick Access Cards -->
        <div class="quick-grid">

            <a class="quick-card" href="profile.php">
                <h3>Complete profile</h3>
                <p>
                    Add your college, skills and resume to stand out.
                </p>
            </a>

            <a class="quick-card" href="internships.php">
                <h3>Find a role</h3>
                <p>
                    Browse current opportunities and apply in a few clicks.
                </p>
            </a>

            <a class="quick-card" href="applications.php">
                <h3>Track applications</h3>
                <p>
                    See the latest status for every application.
                </p>
            </a>

        </div>

    </main>

</body>
</html>
