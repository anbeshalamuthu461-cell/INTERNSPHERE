
<?php
// 1. Start session
session_start();

// 2. Connect to database
require_once __DIR__ . '/../config/database.php';

// 3. Allow only student accounts
require_role('student');

// 4. Load database
$data = db_load();

// 5. Get search filters
$search = trim($_GET['search'] ?? '');
$location = trim($_GET['location'] ?? '');
$technicalSkill = trim($_GET['technical_skill'] ?? '');
$developerSkill = trim($_GET['developer_skill'] ?? '');

// 6. Initialize results
$rows = [];

// 7. Filter internships
foreach (($data['internships'] ?? []) as $i) {

    // Only show open internships
    if (($i['status'] ?? 'Open') !== 'Open') {
        continue;
    }

    // Get company details
    $c = db_company($data, (int) ($i['company_id'] ?? 0));

    if (!$c) {
        continue;
    }

    // Prepare searchable text
    $hay = strtolower(
        ($i['title'] ?? '') . ' ' .
        ($i['description'] ?? '') . ' ' .
        ($c['company_name'] ?? '') . ' ' .
        ($i['skills'] ?? '')
    );

    // Keyword filter
    if (
        $search !== '' &&
        strpos($hay, strtolower($search)) === false
    ) {
        continue;
    }

    // Technical skill filter
    if (
        $technicalSkill !== '' &&
        stripos($hay, $technicalSkill) === false
    ) {
        continue;
    }

    // Developer skill filter
    if (
        $developerSkill !== '' &&
        stripos($hay, $developerSkill) === false
    ) {
        continue;
    }

    // Location filter
    if (
        $location !== '' &&
        stripos((string) ($i['location'] ?? ''), $location) === false
    ) {
        continue;
    }

    // Attach company name
    $i['company_name'] = $c['company_name'] ?? 'Unknown Company';

    $rows[] = $i;
}

// 8. Sort newest first
db_sort_newest($rows);

// 9. Technical skill options
$technicalSkills = [
    'HTML',
    'CSS',
    'JavaScript',
    'PHP',
    'Python',
    'Java',
    'SQL',
    'MySQL',
    'React',
    'Node.js',
    'Git'
];

// 10. Developer skill options
$developerSkills = [
    'Frontend Development',
    'Backend Development',
    'Full Stack Development',
    'Web Development',
    'API Development',
    'Software Development',
    'Mobile App Development'
];

// Helper for safely retaining filter values
function selectedOption(string $current, string $option): string
{
    return $current === $option ? 'selected' : '';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <meta
        name="description"
        content="Explore internships, filter opportunities by skills and location, and manage your applications with InternSphere."
    >

    <link rel="stylesheet" href="../css/style.css?v=6">

    <style>
        .internships-page {
            max-width: 1200px;
            margin: 0 auto;
        }

        .page-header {
            margin-bottom: 28px;
        }

        .eyebrow {
            display: inline-block;
            color: #fbbf24;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2px;
            margin-bottom: 12px;
        }

        .page-header h1 {
            margin: 0 0 14px;
            font-size: 36px;
            font-weight: 800;
            line-height: 1.3;
        }

        .page-header p {
            max-width: 720px;
            line-height: 1.8;
            color: #cbd5e1;
        }

        /* Search form */
        .internship-search {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 30px;
        }

        .internship-search input,
        .internship-search select {
            flex: 1 1 210px;
            min-width: 0;
            box-sizing: border-box;
        }

        .filter-label {
            flex: 1 1 100%;
            margin: 8px 0 -5px;
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .internship-search button,
        .internship-search a {
            cursor: pointer;
        }

        /* Google search button */
        .google-search-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 11px 18px;
            border: 1px solid #d1d5db;
            border-radius: 9px;
            background: #fff;
            color: #1f2937;
            font-weight: 700;
            text-decoration: none;
            transition: 0.2s ease;
        }

        .google-search-btn:hover {
            background: #f3f4f6;
            transform: translateY(-1px);
        }

        /* Internship cards */
        .internship-grid {
            display: grid;
            grid-template-columns: repeat(
                auto-fit,
                minmax(260px, 1fr)
            );
            gap: 22px;
        }

        .internship-card {
            min-width: 0;
            padding: 24px;
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            overflow-wrap: anywhere;
            transition: transform 0.25s ease;
        }

        .internship-card:hover {
            transform: translateY(-3px);
        }

        .internship-card h2 {
            margin: 16px 0 8px;
        }

        .internship-card h4 {
            margin: 0 0 14px;
        }

        .internship-card p {
            line-height: 1.7;
        }

        .internship-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 10px 0 22px;
        }

        .internship-tags span {
            display: inline-block;
            padding: 7px 10px;
            border-radius: 8px;
            font-size: 13px;
            overflow-wrap: anywhere;
        }

        .internship-card .btn {
            margin-top: auto;
            text-decoration: none;
        }

        .internship-empty {
            grid-column: 1 / -1;
            padding: 24px;
            border-radius: 14px;
            line-height: 1.7;
        }

        @media (max-width: 600px) {
            .page-header h1 {
                font-size: 27px;
            }

            .internship-card {
                padding: 20px;
            }

            .internship-search {
                flex-direction: column;
            }

            .internship-search input,
            .internship-search select,
            .internship-search button,
            .internship-search a {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>

<body>

    <!-- Student navigation -->
    <?php include __DIR__ . '/student_nav.php'; ?>

    <main class="dashboard internships-page">

        <!-- Page heading -->
        <div class="page-header">

            <span class="eyebrow">CAREER OPPORTUNITIES</span>

            <h1>Discover Opportunities. Build Your Future.</h1>

            <p>
                Explore internship opportunities, connect with
                companies, and take the next step toward achieving
                your professional goals with InternSphere.
            </p>

        </div>

        <!-- Search form -->
        <form
            class="internship-search"
            method="get"
            action="internships.php"
            id="internshipSearchForm"
        >

            <input
                type="search"
                name="search"
                id="searchKeyword"
                value="<?= e($search) ?>"
                placeholder="Search role, company, or keyword"
                aria-label="Search internships"
            >

            <input
                type="text"
                name="location"
                id="searchLocation"
                value="<?= e($location) ?>"
                placeholder="Enter location"
                aria-label="Filter by location"
            >

            <!-- Technical skills -->
            <label class="filter-label" for="technicalSkill">
                Technical Skills
            </label>

            <select
                name="technical_skill"
                id="technicalSkill"
                aria-label="Filter by technical skill"
            >
                <option value="">All Technical Skills</option>

                <?php foreach ($technicalSkills as $skill): ?>
                    <option
                        value="<?= e($skill) ?>"
                        <?= selectedOption($technicalSkill, $skill) ?>
                    >
                        <?= e($skill) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- Developer skills -->
            <label class="filter-label" for="developerSkill">
                Developer Skills
            </label>

            <select
                name="developer_skill"
                id="developerSkill"
                aria-label="Filter by developer skill"
            >
                <option value="">All Developer Skills</option>

                <?php foreach ($developerSkills as $skill): ?>
                    <option
                        value="<?= e($skill) ?>"
                        <?= selectedOption($developerSkill, $skill) ?>
                    >
                        <?= e($skill) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- Search local database -->
            <button class="btn primary" type="submit">
                Search InternSphere
            </button>

            <!-- Search Google separately -->
            <button
                class="google-search-btn"
                type="button"
                id="googleSearchButton"
            >
                Search Google ↗
            </button>

            <!-- Clear filters -->
            <?php if (
                $search !== '' ||
                $location !== '' ||
                $technicalSkill !== '' ||
                $developerSkill !== ''
            ): ?>
                <a class="btn" href="internships.php">
                    Clear Filters
                </a>
            <?php endif; ?>

        </form>

        <!-- Database results -->
        <div class="internship-grid">

            <?php if (empty($rows)): ?>

                <div class="table-card internship-empty">

                    <h3>No Matching Internships Found</h3>

                    <p>
                        No open internships match your selected filters.
                        Try another skill or location, or clear your filters.
                    </p>

                    <a class="btn primary" href="internships.php">
                        View All Internships
                    </a>

                </div>

            <?php else: ?>

                <?php foreach ($rows as $row): ?>

                    <article class="internship-card">

                        <span class="status open">Open</span>

                        <h2>
                            <?= e($row['title'] ?? 'Internship') ?>
                        </h2>

                        <h4>
                            <?= e($row['company_name']) ?>
                        </h4>

                        <p>
                            <?= e(
                                $row['description']
                                ?? 'No description available.'
                            ) ?>
                        </p>

                        <div class="tags internship-tags">

                            <span>
                                <?= e(
                                    $row['location']
                                    ?? 'Location not specified'
                                ) ?>
                            </span>

                            <?php if (!empty($row['skills'])): ?>
                                <span>
                                    <?= e($row['skills']) ?>
                                </span>
                            <?php endif; ?>

                            <?php if (!empty($row['duration'])): ?>
                                <span>
                                    <?= e($row['duration']) ?>
                                </span>
                            <?php endif; ?>

                        </div>

                        <a
                            class="btn primary"
                            href="apply.php?id=<?= (int) ($row['id'] ?? 0) ?>"
                        >
                            View &amp; Apply
                        </a>

                    </article>

                <?php endforeach; ?>

            <?php endif; ?>

        </div>

    </main>

    <!-- Google search: opens in a new tab -->
    <script>
        document
            .getElementById('googleSearchButton')
            .addEventListener('click', function () {

                const keyword = document
                    .getElementById('searchKeyword')
                    .value.trim();

                const location = document
                    .getElementById('searchLocation')
                    .value.trim();

                const technicalSkill = document
                    .getElementById('technicalSkill')
                    .value;

                const developerSkill = document
                    .getElementById('developerSkill')
                    .value;

                const terms = [
                    keyword,
                    location,
                    technicalSkill,
                    developerSkill,
                    'internship opportunities'
                ].filter(Boolean);

                const query = terms.join(' ');

                const googleUrl =
                    'https://www.google.com/search?q=' +
                    encodeURIComponent(query);

                // Open Google in a separate tab
                const newTab = window.open(
                    googleUrl,
                    '_blank',
                    'noopener,noreferrer'
                );

                // The browser may block pop-ups.
                // If blocked, the user can still submit a Google search
                // by allowing pop-ups for this site.
            });
    </script>

</body>
</html>
