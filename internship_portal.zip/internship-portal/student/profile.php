
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('student');

$data = db_load();
$uid = (int) $_SESSION['user_id'];

$user = db_user($data, $uid);
$student = db_student_by_user($data, $uid);

$message = '';
$messageType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $phone = trim($_POST['phone'] ?? '');
    $college = trim($_POST['college'] ?? '');
    $course = trim($_POST['course'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $bio = trim($_POST['bio'] ?? '');

    $resume = $student['resume'] ?? '';

    // Resume upload validation
    if (
        isset($_FILES['resume']) &&
        $_FILES['resume']['error'] !== UPLOAD_ERR_NO_FILE
    ) {

        if ($_FILES['resume']['error'] !== UPLOAD_ERR_OK) {

            $message = 'Resume upload failed.';
            $messageType = 'error';

        } elseif (
            strtolower(
                pathinfo(
                    $_FILES['resume']['name'],
                    PATHINFO_EXTENSION
                )
            ) !== 'pdf'
        ) {

            $message = 'Please upload your resume in PDF format.';
            $messageType = 'error';

        } elseif ($_FILES['resume']['size'] > 5 * 1024 * 1024) {

            $message = 'Resume must be smaller than 5 MB.';
            $messageType = 'error';

        } else {

            $dir = __DIR__ . '/../uploads';

            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }

            $file = 'resume_' . $uid . '_' . time() . '.pdf';

            if (
                move_uploaded_file(
                    $_FILES['resume']['tmp_name'],
                    $dir . '/' . $file
                )
            ) {
                $resume = $file;
            } else {
                $message = 'Unable to save your resume.';
                $messageType = 'error';
            }
        }
    }

    // Save profile details
    if ($messageType === 'success') {

        $updated = false;

        foreach ($data['students'] as &$s) {

            if ((int) $s['user_id'] === $uid) {

                $s['phone'] = $phone;
                $s['college'] = $college;
                $s['course'] = $course;
                $s['skills'] = $skills;
                $s['bio'] = $bio;
                $s['resume'] = $resume;

                $updated = true;
                break;
            }
        }

        unset($s);

        if ($updated && db_save($data)) {

            $message = 'Your professional profile has been updated successfully.';
            $student = db_student_by_user($data, $uid);

        } else {

            $message = 'Unable to update your profile. Please try again.';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>
        .profile-intro {
            margin-bottom: 28px;
        }

        .profile-intro h1 {
            margin-bottom: 12px;
        }

        .profile-intro .profile-description {
            max-width: 650px;
            line-height: 1.7;
        }

        .profile-form-card {
            max-width: 900px;
            margin: 0 auto;
        }

        .profile-section-title {
            margin: 10px 0 20px;
            font-size: 19px;
        }

        .profile-form-card label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .profile-form-card input,
        .profile-form-card textarea {
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        .profile-form-card input:disabled {
            opacity: 0.8;
            cursor: not-allowed;
        }

        .profile-form-card textarea {
            resize: vertical;
            line-height: 1.6;
        }

        .profile-resume-info {
            margin: -8px 0 20px;
            font-size: 14px;
        }

        .profile-save-button {
            margin-top: 8px;
        }
    </style>
</head>

<body>

    <?php include 'student_nav.php'; ?>

    <main class="dashboard narrow">

        <div class="page-heading profile-intro">
            <div>
                <p class="eyebrow">CAREER PROFILE</p>

                <h1>Build Your Professional Profile.</h1>

                <p class="profile-description">
                    A well-crafted profile helps companies better understand
                    your skills, experience, and potential.
                </p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
                <?= e($message) ?>
            </div>
        <?php endif; ?>

        <div class="form-card profile-form-card">

            <form method="POST" enctype="multipart/form-data">

                <h2 class="profile-section-title">
                    Personal Information
                </h2>

                <div class="form-grid">

                    <div>
                        <label for="name">Full Name</label>

                        <input
                            type="text"
                            id="name"
                            value="<?= e($user['name'] ?? '') ?>"
                            disabled
                        >
                    </div>

                    <div>
                        <label for="email">Email Address</label>

                        <input
                            type="email"
                            id="email"
                            value="<?= e($user['email'] ?? '') ?>"
                            disabled
                        >
                    </div>

                    <div>
                        <label for="phone">Phone Number</label>

                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value="<?= e($student['phone'] ?? '') ?>"
                            placeholder="+91 98765 43210"
                        >
                    </div>

                    <div>
                        <label for="college">College / University</label>

                        <input
                            type="text"
                            id="college"
                            name="college"
                            value="<?= e($student['college'] ?? '') ?>"
                            placeholder="Enter your college or university"
                        >
                    </div>

                    <div>
                        <label for="course">Course / Degree</label>

                        <input
                            type="text"
                            id="course"
                            name="course"
                            value="<?= e($student['course'] ?? '') ?>"
                            placeholder="e.g. B.E. Computer Science"
                        >
                    </div>

                    <div>
                        <label for="skills">Key Skills</label>

                        <input
                            type="text"
                            id="skills"
                            name="skills"
                            value="<?= e($student['skills'] ?? '') ?>"
                            placeholder="e.g. PHP, JavaScript, MySQL"
                        >
                    </div>

                </div>

                <h2 class="profile-section-title">
                    Professional Summary
                </h2>

                <label for="bio">About You</label>

                <textarea
                    id="bio"
                    name="bio"
                    rows="5"
                    placeholder="Introduce your academic background, key skills, projects, and career goals..."
                ><?= e($student['bio'] ?? '') ?></textarea>

                <h2 class="profile-section-title">
                    Resume
                </h2>

                <label for="resume">
                    Upload Your Resume (PDF, maximum 5 MB)
                </label>

                <input
                    type="file"
                    id="resume"
                    name="resume"
                    accept=".pdf,application/pdf"
                >

                <?php if (!empty($student['resume'])): ?>
                    <p class="small-text profile-resume-info">
                        Current resume:
                        <?= e($student['resume']) ?>
                    </p>
                <?php endif; ?>

                <button
                    class="btn primary profile-save-button"
                    type="submit"
                >
                    Save Profile Changes
                </button>

            </form>

        </div>

    </main>

</body>
</html>
