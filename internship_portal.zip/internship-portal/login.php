
<?php
session_start();

require_once __DIR__ . '/config/database.php';

$data = db_load();
$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');

    $user = db_find_user_by_email($data, $email);

    if (!$user || !password_verify($password, $user['password'])) {
        $error = 'Invalid email or password.';
    } else {
        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        header(
            'Location: ' .
            ($user['role'] === 'student'
                ? 'student/dashboard.php'
                : 'company/dashboard.php')
        );

        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link rel="stylesheet" href="css/style.css?v=10">

    <style>
        .login-topbar {
            width: min(1100px, 92%);
            margin: 20px auto 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }

        .login-home-link {
            color: var(--muted);
            font-size: 13px;
            text-decoration: none;
        }

        .login-home-link:hover {
            color: #fff;
        }

        .language-selector {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 10px;
            border: 1px solid rgba(124, 92, 255, .45);
            border-radius: 22px;
            background: rgba(20, 20, 40, .9);
        }

        .language-selector select {
            width: auto;
            max-width: 140px;
            margin: 0;
            padding: 5px 2px;
            border: none;
            background: transparent;
            color: #f8fafc;
            font-size: 12px;
            cursor: pointer;
        }

        .language-selector select option {
            background: #fff;
            color: #111827;
        }

        .login-welcome img {
            display: block;
            width: 100%;
            max-height: 230px;
            object-fit: contain;
            margin: 0 auto;
        }

        .login-welcome {
            margin-bottom: 20px;
        }

        #google_translate_element {
            position: absolute;
            left: -9999px;
            top: -9999px;
            width: 1px;
            height: 1px;
            overflow: hidden;
        }

        .goog-te-banner-frame,
        .goog-te-gadget-icon,
        #goog-gt-tt {
            display: none !important;
        }

        body {
            top: 0 !important;
        }

        @media (max-width: 600px) {
            .login-topbar {
                align-items: flex-start;
                flex-wrap: wrap;
            }
        }
    </style>
</head>

<body class="auth-page">

    <!-- Top navigation -->
    <div class="login-topbar">

        <a href="index.php" class="login-home-link">
            ← <span data-translate="home">Home</span>
        </a>

        <!-- Language selector -->
        <div class="language-selector">
            <span aria-hidden="true">🌐</span>

            <label for="languageSelect" style="display:none;">
                Language
            </label>

            <select id="languageSelect" aria-label="Select language">
                <option value="en">Language: English</option>
                <option value="ta">தமிழ் (Tamil)</option>
                <option value="hi">हिन्दी (Hindi)</option>
                <option value="te">తెలుగు (Telugu)</option>
            </select>
        </div>

    </div>

    <!-- Hidden Google Translate widget -->
    <div id="google_translate_element"></div>

    <div class="auth-container">

        <!-- LEFT SIDE -->
        <div class="auth-brand">

            <a href="index.php" class="logo">
                Intern<span>Sphere</span>
            </a>

            <div class="auth-intro">

                <p class="eyebrow" data-translate="welcome">
                    WELCOME TO INTERNSPHERE
                </p>

                <h1>
                    <span data-translate="career_line1">Your Career Journey</span>
                    <span data-translate="career_line2">Starts Here.</span>
                </h1>

                <p class="auth-description" data-translate="career_description">
                    Explore career opportunities, manage your
                    applications, and take the next step toward
                    your professional goals.
                </p>

            </div>

        </div>

        <!-- RIGHT SIDE: LOGIN CARD -->
        <div class="auth-card">

            <div class="login-welcome">

                <img
                    src="css/images/internsphere-welcome.png"
                    alt="Welcome to InternSphere"
                    loading="eager"
                >

            </div>

            <h2 data-translate="login_heading">
                Sign in to your account
            </h2>

            <p class="muted" data-translate="login_description">
                Enter your registered email and password to continue.
            </p>

            <?php if ($error !== ''): ?>
                <div class="alert error">
                    <?= e($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php" onsubmit="return validateLogin()">

                <label for="email" data-translate="email_label">
                    Email address
                </label>

                <input
                    type="email"
                    name="email"
                    id="email"
                    value="<?= e($email) ?>"
                    placeholder="you@example.com"
                    autocomplete="email"
                    required
                >

                <label for="password" data-translate="password_label">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter your password"
                    autocomplete="current-password"
                    required
                >

                <button class="btn primary full" type="submit" data-translate="sign_in">
                    Sign In
                </button>

            </form>

            <p class="auth-bottom">
                <span data-translate="no_account">Don't have an account?</span>
                <a href="register.php" data-translate="create_account">
                    Create an account
                </a>
            </p>

        </div>

    </div>

    <script>
        function googleTranslateElementInit() {
            new google.translate.TranslateElement(
                {
                    pageLanguage: 'en',
                    includedLanguages: 'en,ta,hi,te',
                    autoDisplay: false
                },
                'google_translate_element'
            );
        }

        document.addEventListener('DOMContentLoaded', function () {
            const languageSelect = document.getElementById('languageSelect');

            languageSelect.addEventListener('change', function () {
                const language = this.value;

                if (language === 'en') {
                    document.cookie =
                        'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/';

                    document.cookie =
                        'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; domain=' +
                        window.location.hostname;

                    window.location.reload();
                    return;
                }

                const applyTranslation = function () {
                    const combo = document.querySelector('.goog-te-combo');

                    if (combo) {
                        combo.value = language;
                        combo.dispatchEvent(new Event('change'));
                        return true;
                    }

                    return false;
                };

                if (!applyTranslation()) {
                    let attempts = 0;

                    const timer = setInterval(function () {
                        attempts++;

                        if (applyTranslation() || attempts >= 20) {
                            clearInterval(timer);
                        }
                    }, 500);
                }
            });
        });
    </script>

    <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="js/validation.js"></script>

</body>
</html>
