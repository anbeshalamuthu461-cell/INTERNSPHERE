
<?php
session_start();
require_once __DIR__ . '/config/database.php';

$data = db_load();

$error = '';
$success = '';

$first_name = '';
$last_name = '';
$name = '';
$email = '';
$role = 'student';
$age = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $name = trim($first_name . ' ' . $last_name);
    $email = trim($_POST['email'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $role = $_POST['role'] ?? 'student';
    $age_input = trim((string) ($_POST['age'] ?? ''));
    $age = filter_var($age_input, FILTER_VALIDATE_INT);

    if (
        $first_name === '' ||
        $last_name === '' ||
        $email === '' ||
        $password === '' ||
        $age_input === ''
    ) {
        $error = 'Please fill in all required fields.';
    } elseif (
        $age === false ||
        $age < 16 ||
        $age > 100
    ) {
        $error = 'Please enter a valid age between 16 and 100.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must contain at least 6 characters.';
    } elseif (!in_array($role, ['student', 'company'], true)) {
        $error = 'Please select a valid account type.';
    } elseif (db_find_user_by_email($data, $email)) {
        $error = 'An account with this email already exists.';
    } else {
        $userId = db_next_id($data, 'users');

        $data['users'][] = [
            'id' => $userId,
            'name' => $name,
            'age' => $age,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role,
            'created_at' => db_now()
        ];

        if ($role === 'student') {
            $data['students'][] = [
                'id' => db_next_id($data, 'students'),
                'user_id' => $userId,
                'phone' => '',
                'college' => '',
                'course' => '',
                'skills' => '',
                'bio' => '',
                'resume' => ''
            ];
        } else {
            $data['companies'][] = [
                'id' => db_next_id($data, 'companies'),
                'user_id' => $userId,
                'company_name' => $name,
                'website' => '',
                'description' => ''
            ];
        }

        if (db_save($data)) {
            $success = 'Account created successfully. You can now sign in.';

            $first_name = '';
            $last_name = '';
            $name = '';
            $email = '';
            $role = 'student';
            $age = '';
        } else {
            $error = 'Unable to save the account. Please check folder permissions.';
        }
    }
}

$errorKeys = [
    'Please fill in all required fields.' => 'requiredError',
    'Please enter a valid age between 16 and 100.' => 'ageError',
    'Please enter a valid email address.' => 'emailError',
    'Password must contain at least 6 characters.' => 'passwordError',
    'Please select a valid account type.' => 'roleError',
    'An account with this email already exists.' => 'existsError',
    'Unable to save the account. Please check folder permissions.' => 'saveError'
];

$errorKey = $errorKeys[$error] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link rel="stylesheet" href="css/style.css?v=5">

    <style>
        .register-language-row {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 16px;
        }

        .language-selector {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 6px 10px;
            border: 1px solid rgba(255, 200, 87, .4);
            border-radius: 24px;
            background: rgba(20, 20, 40, .9);
        }

        .language-selector select {
            width: auto;
            max-width: 145px;
            padding: 5px;
            border: none;
            outline: none;
            background: transparent;
            color: #f8fafc;
            cursor: pointer;
            font-size: 13px;
        }

        .language-selector option {
            color: #111827;
            background: #fff;
        }

        .language-icon {
            font-size: 16px;
        }

        @media (max-width: 600px) {
            .register-language-row {
                margin-bottom: 12px;
            }

            .language-selector select {
                max-width: 125px;
            }
        }
    </style>
</head>

<body class="auth-page">

<div class="auth-container">

    <div class="auth-brand">
        <a href="index.php" class="logo">
            Intern<span>Sphere</span>
        </a>

        <p class="eyebrow" style="margin-top:55px" data-i18n="eyebrow">
            YOUR GATEWAY TO CAREER OPPORTUNITIES
        </p>

        <h1 data-i18n="brandHeading">
            Bridging Talent and Career Opportunities.
        </h1>

        <p data-i18n="brandDescription">
            Build your professional profile, explore career opportunities,
            and seamlessly manage your internship applications—all in one place.
        </p>
    </div>

    <div class="auth-card">

        <div class="register-language-row">
            <div class="language-selector">
                <span class="language-icon" aria-hidden="true">🌐</span>

                <select id="languageSelector" aria-label="Language">
                    <option value="en">Language — English</option>
                    <option value="ta">தமிழ்</option>
                    <option value="hi">हिन्दी</option>
                    <option value="te">తెలుగు</option>
                </select>
            </div>
        </div>

        <h2 data-i18n="createAccount">Create your account</h2>

        <p class="muted" data-i18n="intro">
            Join InternSphere today and unlock new opportunities
            to advance your professional journey.
        </p>

        <?php if ($error): ?>
            <div class="alert error" data-i18n="<?= e($errorKey) ?>">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert success" data-i18n="successMessage">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="" onsubmit="return validateRegister()">

            <div class="name-fields">
                <div class="form-group">
                    <label for="first_name" data-i18n="firstName">First name</label>
                    <input
                        type="text"
                        id="first_name"
                        name="first_name"
                        value="<?= e($first_name) ?>"
                        placeholder="Enter first name"
                        data-i18n-placeholder="firstNamePlaceholder"
                        autocomplete="given-name"
                        required
                    >
                </div>

                <div class="form-group">
                    <label for="last_name" data-i18n="lastName">Last name</label>
                    <input
                        type="text"
                        id="last_name"
                        name="last_name"
                        value="<?= e($last_name) ?>"
                        placeholder="Enter last name"
                        data-i18n-placeholder="lastNamePlaceholder"
                        autocomplete="family-name"
                        required
                    >
                </div>
            </div>

            <div class="form-group">
                <label for="age" data-i18n="age">Age</label>
                <input
                    type="number"
                    id="age"
                    name="age"
                    value="<?= e((string) $age) ?>"
                    placeholder="Enter your age"
                    data-i18n-placeholder="agePlaceholder"
                    min="16"
                    max="100"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email" data-i18n="email">Email address</label>
                <input
                    type="email"
                    name="email"
                    id="email"
                    value="<?= e($email) ?>"
                    placeholder="you@example.com"
                    data-i18n-placeholder="emailPlaceholder"
                    autocomplete="email"
                    required
                >
            </div>

            <div class="form-group">
                <label for="password" data-i18n="password">Password</label>
                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="At least 6 characters"
                    data-i18n-placeholder="passwordPlaceholder"
                    autocomplete="new-password"
                    minlength="6"
                    required
                >
            </div>

            <div class="form-group">
                <label for="role" data-i18n="accountType">Account type</label>

                <select name="role" id="role" required>
                    <option
                        value="student"
                        <?= $role === 'student' ? 'selected' : '' ?>
                        data-i18n="student"
                    >Student</option>

                    <option
                        value="company"
                        <?= $role === 'company' ? 'selected' : '' ?>
                        data-i18n="company"
                    >Company</option>
                </select>
            </div>

            <button class="btn primary full" type="submit" data-i18n="createAccountButton">
                Create account
            </button>
        </form>

        <p class="auth-bottom">
            <span data-i18n="alreadyRegistered">Already registered?</span>
            <a href="login.php" data-i18n="signIn">Sign in</a>
        </p>
    </div>
</div>

<script src="js/validation.js"></script>

<script>
const translations = {
    en: {
        eyebrow: "YOUR GATEWAY TO CAREER OPPORTUNITIES",
        brandHeading: "Bridging Talent and Career Opportunities.",
        brandDescription: "Build your professional profile, explore career opportunities, and seamlessly manage your internship applications—all in one place.",
        createAccount: "Create your account",
        intro: "Join InternSphere today and unlock new opportunities to advance your professional journey.",
        firstName: "First name",
        lastName: "Last name",
        firstNamePlaceholder: "Enter first name",
        lastNamePlaceholder: "Enter last name",
        age: "Age",
        agePlaceholder: "Enter your age",
        email: "Email address",
        emailPlaceholder: "you@example.com",
        password: "Password",
        passwordPlaceholder: "At least 6 characters",
        accountType: "Account type",
        student: "Student",
        company: "Company",
        createAccountButton: "Create account",
        alreadyRegistered: "Already registered?",
        signIn: "Sign in",
        requiredError: "Please fill in all required fields.",
        ageError: "Please enter a valid age between 16 and 100.",
        emailError: "Please enter a valid email address.",
        passwordError: "Password must contain at least 6 characters.",
        roleError: "Please select a valid account type.",
        existsError: "An account with this email already exists.",
        saveError: "Unable to save the account. Please check folder permissions.",
        successMessage: "Account created successfully. You can now sign in."
    },

    ta: {
        eyebrow: "உங்கள் தொழில் வாய்ப்புகளுக்கான நுழைவாயில்",
        brandHeading: "திறமையையும் தொழில் வாய்ப்புகளையும் இணைக்கிறோம்.",
        brandDescription: "உங்கள் தொழில்முறை சுயவிவரத்தை உருவாக்கி, வேலைவாய்ப்புகளை ஆராய்ந்து, உங்கள் இன்டர்ன்ஷிப் விண்ணப்பங்களை ஒரே இடத்தில் நிர்வகிக்கவும்.",
        createAccount: "உங்கள் கணக்கை உருவாக்கவும்",
        intro: "இன்றே InternSphere-இல் இணைந்து உங்கள் தொழில் வளர்ச்சிக்கான புதிய வாய்ப்புகளைப் பெறுங்கள்.",
        firstName: "முதல் பெயர்",
        lastName: "கடைசி பெயர்",
        firstNamePlaceholder: "முதல் பெயரை உள்ளிடவும்",
        lastNamePlaceholder: "கடைசி பெயரை உள்ளிடவும்",
        age: "வயது",
        agePlaceholder: "உங்கள் வயதை உள்ளிடவும்",
        email: "மின்னஞ்சல் முகவரி",
        emailPlaceholder: "you@example.com",
        password: "கடவுச்சொல்",
        passwordPlaceholder: "குறைந்தது 6 எழுத்துகள்",
        accountType: "கணக்கு வகை",
        student: "மாணவர்",
        company: "நிறுவனம்",
        createAccountButton: "கணக்கை உருவாக்கவும்",
        alreadyRegistered: "ஏற்கனவே கணக்கு உள்ளதா?",
        signIn: "உள்நுழைக",
        requiredError: "தேவையான அனைத்து விவரங்களையும் நிரப்பவும்.",
        ageError: "16 முதல் 100 வரை சரியான வயதை உள்ளிடவும்.",
        emailError: "சரியான மின்னஞ்சல் முகவரியை உள்ளிடவும்.",
        passwordError: "கடவுச்சொல்லில் குறைந்தது 6 எழுத்துகள் இருக்க வேண்டும்.",
        roleError: "சரியான கணக்கு வகையைத் தேர்ந்தெடுக்கவும்.",
        existsError: "இந்த மின்னஞ்சலில் ஏற்கனவே கணக்கு உள்ளது.",
        saveError: "கணக்கைச் சேமிக்க முடியவில்லை. கோப்புறை அனுமதிகளைச் சரிபார்க்கவும்.",
        successMessage: "கணக்கு வெற்றிகரமாக உருவாக்கப்பட்டது. இப்போது உள்நுழையலாம்."
    },

    hi: {
        eyebrow: "करियर के अवसरों का प्रवेश द्वार",
        brandHeading: "प्रतिभा और करियर के अवसरों को जोड़ना।",
        brandDescription: "अपनी पेशेवर प्रोफ़ाइल बनाएं, करियर के अवसर खोजें और अपने इंटर्नशिप आवेदनों को एक ही स्थान पर प्रबंधित करें।",
        createAccount: "अपना खाता बनाएं",
        intro: "आज ही InternSphere से जुड़ें और अपने करियर को आगे बढ़ाने के नए अवसर पाएं।",
        firstName: "पहला नाम",
        lastName: "उपनाम",
        firstNamePlaceholder: "पहला नाम दर्ज करें",
        lastNamePlaceholder: "उपनाम दर्ज करें",
        age: "आयु",
        agePlaceholder: "अपनी आयु दर्ज करें",
        email: "ईमेल पता",
        emailPlaceholder: "you@example.com",
        password: "पासवर्ड",
        passwordPlaceholder: "कम से कम 6 अक्षर",
        accountType: "खाते का प्रकार",
        student: "विद्यार्थी",
        company: "कंपनी",
        createAccountButton: "खाता बनाएं",
        alreadyRegistered: "क्या आपका पहले से खाता है?",
        signIn: "साइन इन करें",
        requiredError: "कृपया सभी आवश्यक फ़ील्ड भरें।",
        ageError: "16 से 100 के बीच सही आयु दर्ज करें।",
        emailError: "कृपया सही ईमेल पता दर्ज करें।",
        passwordError: "पासवर्ड में कम से कम 6 अक्षर होने चाहिए।",
        roleError: "कृपया सही खाता प्रकार चुनें।",
        existsError: "इस ईमेल से पहले से एक खाता मौजूद है।",
        saveError: "खाता सेव नहीं हो सका। कृपया फ़ोल्डर की अनुमतियां जांचें।",
        successMessage: "खाता सफलतापूर्वक बन गया। अब आप साइन इन कर सकते हैं।"
    },

    te: {
        eyebrow: "మీ కెరీర్ అవకాశాలకు ప్రవేశద్వారం",
        brandHeading: "ప్రతిభను కెరీర్ అవకాశాలతో అనుసంధానిస్తున్నాము.",
        brandDescription: "మీ ప్రొఫెషనల్ ప్రొఫైల్‌ను రూపొందించండి, కెరీర్ అవకాశాలను అన్వేషించండి మరియు మీ ఇంటర్న్‌షిప్ దరఖాస్తులను ఒకే చోట నిర్వహించండి.",
        createAccount: "మీ ఖాతాను సృష్టించండి",
        intro: "ఈరోజే InternSphereలో చేరి మీ కెరీర్ అభివృద్ధికి కొత్త అవకాశాలను పొందండి.",
        firstName: "మొదటి పేరు",
        lastName: "చివరి పేరు",
        firstNamePlaceholder: "మొదటి పేరును నమోదు చేయండి",
        lastNamePlaceholder: "చివరి పేరును నమోదు చేయండి",
        age: "వయస్సు",
        agePlaceholder: "మీ వయస్సును నమోదు చేయండి",
        email: "ఇమెయిల్ చిరునామా",
        emailPlaceholder: "you@example.com",
        password: "పాస్‌వర్డ్",
        passwordPlaceholder: "కనీసం 6 అక్షరాలు",
        accountType: "ఖాతా రకం",
        student: "విద్యార్థి",
        company: "కంపెనీ",
        createAccountButton: "ఖాతాను సృష్టించండి",
        alreadyRegistered: "ఇప్పటికే ఖాతా ఉందా?",
        signIn: "సైన్ ఇన్",
        requiredError: "దయచేసి అవసరమైన అన్ని వివరాలను నమోదు చేయండి.",
        ageError: "16 నుండి 100 మధ్య సరైన వయస్సును నమోదు చేయండి.",
        emailError: "దయచేసి సరైన ఇమెయిల్ చిరునామాను నమోదు చేయండి.",
        passwordError: "పాస్‌వర్డ్‌లో కనీసం 6 అక్షరాలు ఉండాలి.",
        roleError: "దయచేసి సరైన ఖాతా రకాన్ని ఎంచుకోండి.",
        existsError: "ఈ ఇమెయిల్‌తో ఇప్పటికే ఖాతా ఉంది.",
        saveError: "ఖాతాను సేవ్ చేయలేకపోయాము. ఫోల్డర్ అనుమతులను తనిఖీ చేయండి.",
        successMessage: "ఖాతా విజయవంతంగా సృష్టించబడింది. ఇప్పుడు సైన్ ఇన్ చేయవచ్చు."
    }
};

const languageSelector = document.getElementById('languageSelector');

function applyLanguage(language) {
    if (!Object.prototype.hasOwnProperty.call(translations, language)) {
        language = 'en';
    }

    const dictionary = translations[language];

    document.documentElement.lang = language;

    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.dataset.i18n;

        if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
            element.textContent = dictionary[key];
        }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(element => {
        const key = element.dataset.i18nPlaceholder;

        if (Object.prototype.hasOwnProperty.call(dictionary, key)) {
            element.placeholder = dictionary[key];
        }
    });

    languageSelector.value = language;

    try {
        localStorage.setItem('internsphere_language', language);
    } catch (error) {
        // Language selection still works for the current page.
    }
}

languageSelector.addEventListener('change', function () {
    applyLanguage(this.value || 'en');
});

// English by default; remember the user's explicit selection.
let savedLanguage = 'en';

try {
    savedLanguage = localStorage.getItem('internsphere_language') || 'en';
} catch (error) {
    savedLanguage = 'en';
}

applyLanguage(savedLanguage);
</script>

</body>
</html>
