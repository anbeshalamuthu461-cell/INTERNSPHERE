
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <style>
        /* Navbar Styles */
        .dashboard-nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 16px;
        }

        /* InternSphere Logo */
        .dashboard-nav .logo {
            font-size: 25px;
            font-weight: 800;
            text-decoration: none;
        }

        .dashboard-nav .logo span {
            color: #fbbf24;
        }

        /* Navigation Links */
        .dashboard-nav .nav-links {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .dashboard-nav .nav-links a {
            text-decoration: none;
            transition: all 0.25s ease;
        }

        /* Gold Logout Button */
        .dashboard-nav .nav-links a.logout-btn {
            background: linear-gradient(135deg, #ffe878, #ffb927);
            color: #111827;
            padding: 10px 18px;
            border-radius: 10px;
            font-weight: 700;
            text-decoration: none;
            display: inline-block;
            transition: all 0.25s ease;
        }

        /* Logout Hover Effect */
        .dashboard-nav .nav-links a.logout-btn:hover {
            background: linear-gradient(135deg, #ffdc55, #f5a900);
            color: #000000;
            transform: translateY(-2px);
            box-shadow: 0 6px 18px rgba(255, 190, 40, 0.25);
        }

        /* Navigation Link Hover */
        .dashboard-nav .nav-links a:not(.logout-btn):hover {
            opacity: 0.8;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .dashboard-nav {
                flex-direction: column;
                align-items: flex-start;
            }

            .dashboard-nav .nav-links {
                gap: 12px;
                width: 100%;
            }
        }
    </style>
</head>

<body>

<nav class="navbar dashboard-nav">

    <!-- InternSphere Logo -->
    <a class="logo" href="dashboard.php">
        Intern<span>Sphere</span>
    </a>

    <!-- Navigation Links -->
    <div class="nav-links">

        <!-- Dashboard -->
        <a href="dashboard.php">
            Dashboard
        </a>

        <!-- Post a New Internship -->
        <a href="add_internship.php">
            Post Internship
        </a>

        <!-- Manage Existing Internships -->
        <a href="internships.php">
            My Internships
        </a>

        <!-- View Applicants -->
        <a href="applicants.php">
            Applicants
        </a>

        <!-- Logout Button -->
        <a href="../logout.php" class="logout-btn">
            Logout
        </a>

    </div>

</nav>

</body>
</html>
