
<?php

// 1. Start the session
session_start();

// 2. Connect to the database
require_once __DIR__ . '/../config/database.php';

// 3. Allow only company accounts
require_role('company');

// 4. Load database data
$data = db_load();

// 5. Get the logged-in company's details
$company = db_company_by_user(
    $data,
    (int) $_SESSION['user_id']
);

// 6. Get the company ID
$cid = (int) ($company['id'] ?? 0);

// 7. Initialize the message
$message = '';

// 8. Handle the Close / Reopen action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id = (int) ($_POST['internship_id'] ?? 0);
    $action = $_POST['action'] ?? '';

    // Find the internship belonging to this company
    foreach ($data['internships'] as &$i) {

        if (
            (int) $i['id'] === $id &&
            (int) $i['company_id'] === $cid
        ) {

            // Change internship status
            if ($action === 'toggle') {

                $i['status'] =
                    ($i['status'] ?? '') === 'Open'
                    ? 'Closed'
                    : 'Open';

                $message = 'Internship status updated.';
            }

            break;
        }
    }

    unset($i);

    // Save updated data
    if ($message !== '') {

        if (db_save($data)) {
            $message = 'Internship status updated successfully.';
        } else {
            $message = 'Unable to update internship status.';
        }
    }
}

// 9. Prepare this company's internship list
$rows = [];

foreach ($data['internships'] as $i) {

    // Show only internships posted by this company
    if ((int) $i['company_id'] !== $cid) {
        continue;
    }

    // Count applications for this internship
    $i['applicant_count'] = count(
        array_filter(
            $data['applications'],
            fn($a) =>
                (int) $a['internship_id'] === (int) $i['id']
        )
    );

    $rows[] = $i;
}

// 10. Sort internships by newest first
db_sort_newest($rows);

// 11. Get notification message
$flash = take_flash();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- InternSphere Project Title -->
    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <style>
        /* Main internship page */
        .internships-page {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Page heading */
        .internships-heading {
            margin-bottom: 28px;
        }

        .internships-heading h1 {
            margin-bottom: 12px;
        }

        .internships-heading p {
            line-height: 1.7;
        }

        /* Table container */
        .internships-table-card {
            width: 100%;
            overflow-x: auto;
            border-radius: 14px;
        }

        .internships-table-card table {
            width: 100%;
            border-collapse: collapse;
        }

        .internships-table-card th,
        .internships-table-card td {
            padding: 16px;
            text-align: left;
            vertical-align: middle;
        }

        /* Internship title */
        .internships-table-card td strong {
            display: inline-block;
            margin-bottom: 6px;
        }

        .internships-table-card small {
            opacity: 0.75;
        }

        /* Status labels */
        .internships-table-card .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            white-space: nowrap;
        }

        .internships-table-card .status.open {
            background: #dcfce7;
            color: #166534;
        }

        .internships-table-card .status.closed {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Action buttons */
        .internships-table-card .btn {
            white-space: nowrap;
            cursor: pointer;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {

            .internships-heading h1 {
                font-size: 27px;
            }

            .internships-table-card th,
            .internships-table-card td {
                padding: 12px;
            }
        }
    </style>

</head>

<body>

    <!-- 12. Display company navigation -->
    <?php include 'company_nav.php'; ?>

    <main class="dashboard internships-page">

        <!-- 13. Page heading -->
        <div class="page-heading internships-heading">

            <div>

                <p class="eyebrow">
                    OPPORTUNITY MANAGEMENT
                </p>

                <h1>
                    My Internships.
                </h1>

                <p>
                    Manage your published opportunities, track applicants,
                    and control whether students can apply.
                </p>

            </div>

            <!-- Add internship button -->
            <a
                class="btn primary"
                href="add_internship.php"
            >
                + Add Internship
            </a>

        </div>

        <!-- 14. Display flash notification -->
        <?php if ($flash): ?>

            <div class="alert <?= ($flash['type'] ?? '') === 'success' ? 'success' : 'error' ?>">

                <?= e($flash['message'] ?? '') ?>

            </div>

        <?php endif; ?>

        <!-- 15. Display status update message -->
        <?php if ($message !== ''): ?>

            <div class="alert <?= str_contains($message, 'successfully') ? 'success' : 'error' ?>">

                <?= e($message) ?>

            </div>

        <?php endif; ?>

        <!-- 16. Internship table -->
        <div class="table-card internships-table-card">

            <table>

                <thead>

                    <tr>
                        <th>Internship Role</th>
                        <th>Location</th>
                        <th>Applicants</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>

                </thead>

                <tbody>

                    <!-- 17. Show empty message if no internships exist -->
                    <?php if (empty($rows)): ?>

                        <tr>
                            <td colspan="5" class="empty">
                                No internships posted yet.
                                Click "Add Internship" to create your first opportunity.
                            </td>
                        </tr>

                    <?php else: ?>

                        <!-- 18. Display each internship -->
                        <?php foreach ($rows as $r): ?>

                            <tr>

                                <!-- Internship title and duration -->
                                <td>

                                    <strong>
                                        <?= e($r['title'] ?? '') ?>
                                    </strong>

                                    <br>

                                    <small>
                                        <?= e($r['duration'] ?: 'Duration not specified') ?>
                                    </small>

                                </td>

                                <!-- Location -->
                                <td>
                                    <?= e($r['location'] ?? 'Not specified') ?>
                                </td>

                                <!-- Applicant count -->
                                <td>
                                    <?= (int) $r['applicant_count'] ?>
                                </td>

                                <!-- Internship status -->
                                <td>

                                    <span class="status <?= ($r['status'] ?? '') === 'Open' ? 'open' : 'closed' ?>">

                                        <?= e($r['status'] ?? 'Closed') ?>

                                    </span>

                                </td>

                                <!-- Close or Reopen action -->
                                <td>

                                    <form method="POST">

                                        <input
                                            type="hidden"
                                            name="internship_id"
                                            value="<?= (int) $r['id'] ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="toggle"
                                        >

                                        <button
                                            class="btn small"
                                            type="submit"
                                        >

                                            <?= ($r['status'] ?? '') === 'Open'
                                                ? 'Close Internship'
                                                : 'Reopen Internship'
                                            ?>

                                        </button>

                                    </form>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>
