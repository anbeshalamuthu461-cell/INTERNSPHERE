
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

require_role('company');

$data = db_load();

$company = db_company_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$cid = (int) ($company['id'] ?? 0);

$error = '';

$title = '';
$description = '';
$location = '';
$skills = '';
$duration = '';
$stipend = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get form values
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $skills = trim($_POST['skills'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $stipend = trim($_POST['stipend'] ?? '');

    // Validate required fields
    if (
        $title === '' ||
        $description === '' ||
        $location === ''
    ) {
        $error = 'Please provide the internship title, description, and location.';

    } elseif ($cid <= 0) {
        $error = 'Company profile not found. Please contact support.';

    } else {

        // Create internship record
        $data['internships'][] = [
            'id' => db_next_id($data, 'internships'),
            'company_id' => $cid,
            'title' => $title,
            'description' => $description,
            'location' => $location,
            'skills' => $skills,
            'duration' => $duration,
            'stipend' => $stipend,
            'status' => 'Open',
            'created_at' => db_now()
        ];

        // Save internship
        if (db_save($data)) {

            flash(
                'success',
                'Your internship opportunity has been published successfully.'
            );

            header('Location: internships.php');
            exit;

        } else {
            $error = 'Unable to publish the internship. Please try again.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Post an Internship | InternSphere</title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <style>
        .post-page {
            max-width: 900px;
            margin: 0 auto;
        }

        .post-heading {
            margin-bottom: 30px;
        }

        .post-heading h1 {
            margin-bottom: 12px;
        }

        .post-description {
            max-width: 650px;
            line-height: 1.7;
        }

        .post-form-card {
            padding: 32px;
            border-radius: 18px;
        }

        .post-section-title {
            margin: 0 0 22px;
            font-size: 20px;
            font-weight: 700;
        }

        .post-form-card label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .post-form-card input,
        .post-form-card textarea {
            width: 100%;
            box-sizing: border-box;
            margin-bottom: 22px;
        }

        .post-form-card textarea {
            resize: vertical;
            line-height: 1.7;
        }

        .post-form-card .form-grid {
            gap: 0 24px;
        }

        .required-note {
            margin-bottom: 24px;
            font-size: 13px;
            opacity: 0.75;
        }

        .post-submit {
            margin-top: 8px;
        }

        @media (max-width: 600px) {
            .post-form-card {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <?php include 'company_nav.php'; ?>

    <main class="dashboard post-page">

        <!-- Page Heading -->
        <div class="page-heading post-heading">
            <div>
                <p class="eyebrow">CREATE AN OPPORTUNITY</p>

                <h1>Publish an Internship.</h1>

                <p class="post-description">
                    Connect with talented students by sharing internship
                    opportunities, essential qualifications, and the skills
                    required to succeed.
                </p>
            </div>
        </div>

        <!-- Error Message -->
        <?php if ($error !== ''): ?>
            <div class="alert error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <!-- Internship Form -->
        <div class="form-card post-form-card">

            <form method="POST" action="">

                <p class="required-note">
                    Fields marked with * are required.
                </p>

                <h2 class="post-section-title">
                    Internship Information
                </h2>

                <!-- Internship Title -->
                <label for="title">
                    Internship Title *
                </label>

                <input
                    type="text"
                    id="title"
                    name="title"
                    value="<?= e($title) ?>"
                    placeholder="e.g. Full Stack Developer Intern"
                    maxlength="150"
                    required
                >

                <!-- Description -->
                <label for="description">
                    Internship Description *
                </label>

                <textarea
                    id="description"
                    name="description"
                    rows="7"
                    placeholder="Describe responsibilities, requirements, qualifications, and learning opportunities..."
                    required
                ><?= e($description) ?></textarea>

                <h2 class="post-section-title">
                    Requirements and Benefits
                </h2>

                <div class="form-grid">

                    <!-- Location -->
                    <div>
                        <label for="location">
                            Work Location *
                        </label>

                        <input
                            type="text"
                            id="location"
                            name="location"
                            value="<?= e($location) ?>"
                            placeholder="e.g. Chennai / Remote"
                            maxlength="150"
                            required
                        >
                    </div>

                    <!-- Skills -->
                    <div>
                        <label for="skills">
                            Required Skills
                        </label>

                        <input
                            type="text"
                            id="skills"
                            name="skills"
                            value="<?= e($skills) ?>"
                            placeholder="e.g. PHP, MySQL, JavaScript"
                        >
                    </div>

                    <!-- Duration -->
                    <div>
                        <label for="duration">
                            Internship Duration
                        </label>

                        <input
                            type="text"
                            id="duration"
                            name="duration"
                            value="<?= e($duration) ?>"
                            placeholder="e.g. 3 months"
                        >
                    </div>

                    <!-- Stipend -->
                    <div>
                        <label for="stipend">
                            Stipend
                        </label>

                        <input
                            type="text"
                            id="stipend"
                            name="stipend"
                            value="<?= e($stipend) ?>"
                            placeholder="e.g. ₹10,000 / month or Unpaid"
                        >
                    </div>

                </div>

                <!-- Submit Button -->
                <button
                    class="btn primary post-submit"
                    type="submit"
                >
                    Publish Internship
                </button>

            </form>

        </div>

    </main>

</body>

</html>
