
<?php
// 1. Start session and connect to database
session_start();

require_once __DIR__ . '/../config/database.php';

// 2. Allow company accounts only
require_role('company');

// 3. Load database information
$data = db_load();

// 4. Get logged-in company details
$company = db_company_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$cid = (int) ($company['id'] ?? 0);

// 5. Get internships posted by this company
$roles = array_values(
    array_filter(
        $data['internships'],
        fn($i) => (int) $i['company_id'] === $cid
    )
);

// 6. Count total applicants for this company's internships
$apps = 0;

foreach ($data['applications'] as $a) {

    $i = db_internship(
        $data,
        (int) $a['internship_id']
    );

    if ($i && (int) $i['company_id'] === $cid) {
        $apps++;
    }
}

// 7. Count open internships
$open = count(
    array_filter(
        $roles,
        fn($i) => ($i['status'] ?? '') === 'Open'
    )
);

// 8. Get notification message
$flash = take_flash();
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- InternSphere Project Title -->
    <title>InternSphere: A Web-Based Student Internship and Recruitment Management System Using PHP and MySQL</title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <style>
        /* Dashboard layout */
        .company-dashboard {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Page heading */
        .company-heading {
            margin-bottom: 30px;
        }

        .company-heading h1 {
            margin-bottom: 12px;
            overflow-wrap: anywhere;
        }

        .company-description {
            max-width: 650px;
            line-height: 1.7;
        }

        /* Dashboard statistics */
        .company-stats {
            margin-bottom: 32px;
        }

        .company-stats .stat-card {
            padding: 24px;
            border-radius: 16px;
            transition: transform 0.25s ease;
        }

        .company-stats .stat-card:hover {
            transform: translateY(-3px);
        }

        .company-stats .stat-card span {
            display: block;
            margin-bottom: 12px;
        }

        .company-stats .stat-card strong {
            font-size: 30px;
        }

        /* Quick action cards */
        .company-quick-actions {
            margin-top: 20px;
        }

        .company-quick-actions .quick-card {
            display: block;
            padding: 24px;
            border-radius: 16px;
            text-decoration: none;
            transition: transform 0.25s ease;
        }

        .company-quick-actions .quick-card:hover {
            transform: translateY(-3px);
        }

        .company-quick-actions .quick-card h3 {
            margin-top: 0;
            margin-bottom: 12px;
        }

        .company-quick-actions .quick-card p {
            line-height: 1.7;
            margin-bottom: 0;
        }

        /* Mobile layout */
        @media (max-width: 600px) {
            .company-heading h1 {
                font-size: 27px;
            }

            .company-stats .stat-card {
                padding: 18px;
            }

            .company-stats .stat-card strong {
                font-size: 25px;
            }

            .company-quick-actions .quick-card {
                padding: 20px;
            }
        }
    </style>

</head>

<body>

    <!-- 9. Display company navigation -->
    <?php include 'company_nav.php'; ?>

    <main class="dashboard company-dashboard">

        <!-- 10. Dashboard heading -->
        <div class="page-heading company-heading">

            <div>

                <p class="eyebrow">
                    COMPANY DASHBOARD
                </p>

                <h1>
                    Welcome,
                    <?= e($company['company_name'] ?? $_SESSION['name']) ?>!
                </h1>

                <p class="company-description">
                    Manage your internship opportunities, connect with
                    talented candidates, and monitor your recruitment
                    progress—all from one place.
                </p>

            </div>

            <!-- Post internship button -->
            <a
                class="btn primary"
                href="add_internship.php"
            >
                Post an Internship
            </a>

        </div>

        <!-- 11. Success or error notification -->
        <?php if ($flash): ?>

            <div class="alert <?= $flash['type'] === 'success' ? 'success' : 'error' ?>">

                <?= e($flash['message']) ?>

            </div>

        <?php endif; ?>

        <!-- 12. Dashboard statistics -->
        <div class="stats-grid company-stats">

            <!-- Total internships -->
            <div class="stat-card">

                <span>Total Internships</span>

                <strong>
                    <?= count($roles) ?>
                </strong>

            </div>

            <!-- Open internships -->
            <div class="stat-card">

                <span>Active Opportunities</span>

                <strong>
                    <?= $open ?>
                </strong>

            </div>

            <!-- Total applications -->
            <div class="stat-card">

                <span>Total Applications</span>

                <strong>
                    <?= $apps ?>
                </strong>

            </div>

        </div>

        <!-- 13. Quick action cards -->
        <div class="quick-grid company-quick-actions">

            <!-- Create internship -->
            <a
                class="quick-card"
                href="add_internship.php"
            >

                <h3>Publish an Opportunity</h3>

                <p>
                    Create new internship listings with role details,
                    required skills, duration, and stipend information.
                </p>

            </a>

            <!-- Manage internships -->
            <a
                class="quick-card"
                href="internships.php"
            >

                <h3>Manage Internships</h3>

                <p>
                    Review your published opportunities and manage
                    their availability as hiring needs change.
                </p>

            </a>

            <!-- Manage applicants -->
            <a
                class="quick-card"
                href="applicants.php"
            >

                <h3>Review Candidates</h3>

                <p>
                    Evaluate applicants, review their skills, and
                    update application statuses throughout recruitment.
                </p>

            </a>

        </div>

    </main>

</body>

</html>
