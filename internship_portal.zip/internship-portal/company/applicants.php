
<?php

// 1. Start session and connect to database
session_start();

require_once __DIR__ . '/../config/database.php';

// 2. Allow company accounts only
require_role('company');

// 3. Load application data
$data = db_load();

// 4. Get the logged-in company's details
$company = db_company_by_user(
    $data,
    (int) $_SESSION['user_id']
);

$cid = (int) ($company['id'] ?? 0);

// 5. Allowed application statuses
$allowed = [
    'Under Review',
    'Shortlisted',
    'Interview',
    'Selected',
    'Rejected'
];

// 6. Initialize message
$message = '';
$messageType = 'success';

// 7. Handle status update form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $aid = (int) ($_POST['application_id'] ?? 0);
    $new = $_POST['status'] ?? '';

    // Validate the submitted status
    if (in_array($new, $allowed, true)) {

        $found = false;

        // Find the application and verify company ownership
        foreach ($data['applications'] as &$a) {

            $i = db_internship(
                $data,
                (int) $a['internship_id']
            );

            if (
                (int) $a['id'] === $aid &&
                $i &&
                (int) $i['company_id'] === $cid
            ) {
                $a['status'] = $new;
                $found = true;
                break;
            }
        }

        unset($a);

        // Save updated application status
        if ($found && db_save($data)) {

            $message = 'Application status updated successfully.';

        } else {

            $message = 'Unable to update the application status.';
            $messageType = 'error';
        }

    } else {

        $message = 'Please select a valid application status.';
        $messageType = 'error';
    }
}

// 8. Prepare the applicant list
$rows = [];

foreach ($data['applications'] as $a) {

    // Get the internship for this application
    $i = db_internship(
        $data,
        (int) $a['internship_id']
    );

    // Show only applications for this company
    if (!$i || (int) $i['company_id'] !== $cid) {
        continue;
    }

    // Find the student profile
    $s = null;

    foreach ($data['students'] as $st) {

        if ((int) $st['id'] === (int) $a['student_id']) {
            $s = $st;
            break;
        }
    }

    // Get the student's account details
    $u = $s
        ? db_user($data, (int) $s['user_id'])
        : null;

    if (!$u) {
        continue;
    }

    // Add student and internship details
    $a['student_name'] = $u['name'];
    $a['email'] = $u['email'];
    $a['skills'] = $s['skills'] ?? '';
    $a['college'] = $s['college'] ?? '';
    $a['title'] = $i['title'];

    $rows[] = $a;
}

// 9. Sort newest applications first
usort($rows, function ($a, $b) {
    return strcmp(
        $b['applied_at'] ?? '',
        $a['applied_at'] ?? ''
    );
});

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <!-- Updated website title -->
    <title>Applicants | InternSphere</title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >

    <style>
        .applicants-heading {
            margin-bottom: 28px;
        }

        .applicants-heading h1 {
            margin-bottom: 10px;
        }

        .applicants-description {
            max-width: 650px;
            line-height: 1.7;
        }

        .applicants-table-card {
            overflow-x: auto;
            border-radius: 16px;
        }

        .applicants-table-card table {
            width: 100%;
            min-width: 850px;
            border-collapse: collapse;
        }

        .applicants-table-card th,
        .applicants-table-card td {
            padding: 16px;
            text-align: left;
            vertical-align: middle;
        }

        .applicants-table-card th {
            font-weight: 700;
            white-space: nowrap;
        }

        .applicant-name {
            font-weight: 700;
        }

        .applicant-email {
            display: inline-block;
            margin-top: 5px;
            overflow-wrap: anywhere;
        }

        .applicant-skills {
            max-width: 220px;
            overflow-wrap: anywhere;
        }

        .applicant-status-form {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 230px;
        }

        .applicant-status-form select {
            min-width: 145px;
        }

        .applicant-status-form button {
            white-space: nowrap;
        }

        .applicants-empty {
            padding: 28px;
            text-align: center;
        }

        @media (max-width: 600px) {
            .applicants-heading h1 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

    <!-- 10. Company navigation -->
    <?php include 'company_nav.php'; ?>

    <main class="dashboard">

        <!-- 11. Page heading -->
        <div class="page-heading applicants-heading">

            <div>
                <p class="eyebrow">CANDIDATE MANAGEMENT</p>

                <h1>Manage Applicants.</h1>

                <p class="applicants-description">
                    Review candidate profiles, evaluate relevant skills,
                    and keep applicants informed by updating their
                    application status.
                </p>
            </div>

        </div>

        <!-- 12. Display success or error message -->
        <?php if ($message): ?>

            <div class="alert <?= $messageType === 'success' ? 'success' : 'error' ?>">
                <?= e($message) ?>
            </div>

        <?php endif; ?>

        <!-- 13. Applicants table -->
        <div class="table-card applicants-table-card">

            <table>

                <thead>
                    <tr>
                        <th>Candidate</th>
                        <th>Internship</th>
                        <th>Skills</th>
                        <th>Applied Date</th>
                        <th>Current Status</th>
                        <th>Update Status</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (empty($rows)): ?>

                        <tr>
                            <td colspan="6" class="empty applicants-empty">
                                <strong>No applicants yet.</strong>
                                <p>
                                    Applications will appear here when
                                    students apply for your internships.
                                </p>
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($rows as $r): ?>

                            <tr>

                                <!-- Candidate details -->
                                <td>
                                    <strong class="applicant-name">
                                        <?= e($r['student_name']) ?>
                                    </strong>

                                    <br>

                                    <small class="applicant-email">
                                        <?= e($r['email']) ?>
                                    </small>
                                </td>

                                <!-- Internship title -->
                                <td>
                                    <?= e($r['title']) ?>
                                </td>

                                <!-- Candidate skills -->
                                <td>
                                    <div class="applicant-skills">
                                        <?= e($r['skills'] ?: 'Not provided') ?>
                                    </div>
                                </td>

                                <!-- Application date -->
                                <td>
                                    <?php
                                    $appliedAt = strtotime(
                                        $r['applied_at'] ?? ''
                                    );
                                    ?>

                                    <?= $appliedAt
                                        ? e(date('d M Y', $appliedAt))
                                        : 'Not available'
                                    ?>
                                </td>

                                <!-- Current application status -->
                                <td>
                                    <span class="status <?= e(status_class($r['status'] ?? '')) ?>">
                                        <?= e($r['status'] ?? 'Under Review') ?>
                                    </span>
                                </td>

                                <!-- Update status form -->
                                <td>
                                    <form
                                        method="POST"
                                        action=""
                                        class="inline-form applicant-status-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="application_id"
                                            value="<?= (int) $r['id'] ?>"
                                        >

                                        <select
                                            name="status"
                                            aria-label="Application status"
                                        >

                                            <?php foreach ($allowed as $status): ?>

                                                <option
                                                    value="<?= e($status) ?>"
                                                    <?= ($r['status'] ?? '') === $status ? 'selected' : '' ?>
                                                >
                                                    <?= e($status) ?>
                                                </option>

                                            <?php endforeach; ?>

                                        </select>

                                        <button
                                            class="btn small"
                                            type="submit"
                                        >
                                            Save
                                        </button>

                                    </form>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>
